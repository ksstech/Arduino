Compiled on Arduino 2.3.6 IDE with Espressif ESP32 3.3.0 package
Copy the required libs in the Arduino IDE Libraries folder as no Portable option available for 2.0