/**
 * OneWireTag.h  —  DS1990 / RW1990 iButton read, write and verify
 *                  for ATtiny3224 / megaTinyCore 2.6.x
 *
 * LIBRARY APPROACH
 * ────────────────
 * Paul Stoffregen's OneWire library handles every standard 1-Wire operation:
 *   reset()       480 µs LOW + 70 µs presence sample, calibrated to F_CPU
 *   write(byte)   8 write slots, calibrated to F_CPU
 *   read()        8 read slots, samples at 13 µs — within tRDV = 15 µs max
 *   search(addr)  full SEARCH ROM algorithm
 *
 * Custom code in this class is limited to ONE non-standard operation:
 *   _writeBit()   RW1990 programming pulse (5–10 ms) — the library's 60 µs
 *                 slots cannot express this; no library alternative exists.
 *
 * SUPPORTED TAGS
 * ──────────────
 *  Family 0x01   DS1990A, DS1990R  (read-only)
 *                RW1990, RW1990.1  (writable, command 0xD1)
 *                RW1990.2          (writable, may need alternate command 0xC1)
 *
 * HARDWARE
 * ────────
 *  PA4 → 1-Wire bus, 4.7 kΩ pullup to VCC (3.3 V) required.
 *  At 3.3 V: ~0.7 mA — adequate for reads.
 *  For RW1990 write reliability consider 2.2 kΩ or a strong-pullup circuit.
 *  Single-tag topology required during write/verify.
 *
 * IDE SETTINGS (mandatory)
 * ────────────────────────
 *  Clock: 10 MHz internal  (3.3 V VCC → Speed Grade 2, max 10 MHz per DS40002315)
 *  millis()/micros(): TCB0 or TCB1 — must NOT be TCA0
 */

#pragma once
#include <Arduino.h>
#include <OneWire.h>

/* ── Bus constants ──────────────────────────────────────────────────────── */
static constexpr uint8_t OW_ROM_BYTES     = 8u;
static constexpr uint8_t OW_FAMILY_DS1990 = 0x01u;

/* ── RW1990 write constants ─────────────────────────────────────────────── */
static constexpr uint8_t RW_CMD_WRITE     = 0xD1u;
static constexpr uint8_t RW_CMD_WRITE_ALT = 0xC1u;
static constexpr uint8_t RW_PULSE_ONE_MS  = 5u;
static constexpr uint8_t RW_PULSE_ZERO_MS = 10u;
static constexpr uint8_t RW_RELEASE_MS    = 2u;
static constexpr uint8_t RW_ENTER_MS      = 10u;
static constexpr uint8_t RW_SETTLE_MS     = 20u;

/* ── Result codes ───────────────────────────────────────────────────────── */
enum class OWResult : uint8_t {
    OK            = 0,
    NO_PRESENCE   = 1,  ///< No presence pulse detected
    CRC_ERROR     = 2,  ///< Data received but CRC mismatch
    WRONG_FAMILY  = 3,  ///< ROM[0] is not a DS1990/RW1990 family byte
    VERIFY_FAIL   = 4,  ///< Read-back after write did not match
    BUS_ERROR     = 5,  ///< Unexpected bus state
};

/* ── OneWireTag class ───────────────────────────────────────────────────── */
class OneWireTag {
public:
    /**
     * Initialise with the 1-Wire bus pin (use PIN_PA4).
     * The pin is driven as INPUT; the external 4.7 kΩ pullup holds it HIGH.
     */
    explicit OneWireTag(uint8_t pin);

    /* ── Read ─────────────────────────────────────────────────────────── */

    /**
     * Read the ROM code from the single tag on the bus (READ ROM 0x33).
     * Returns raw bytes regardless of CRC or family — use for diagnostics.
     * Check result == OWResult::OK before trusting data.
     */
    OWResult readRaw(uint8_t* romCode);

    /**
     * As readRaw(), but additionally validates CRC and family code.
     * Returns OWResult::WRONG_FAMILY for non-DS1990 devices.
     */
    OWResult read(uint8_t* romCode);

    /**
     * SEARCH ROM scan — enumerate multiple tags on the bus.
     * Call resetSearch() before the first scan in each pass.
     */
    OWResult scanNext(uint8_t* romCode);
    void     resetSearch();

    /* ── Write / Program (RW1990 only) ───────────────────────────────── */

    /**
     * Write a new ROM code to an RW1990 tag.
     * Tag must be the ONLY device on the bus during programming.
     */
    OWResult write(const uint8_t* romCode, bool useAltCmd = false);

    /**
     * Verify by reading back and comparing to expected.
     */
    OWResult verify(const uint8_t* expected);

    /**
     * Write + verify.  CRC auto-filled if romCode[7] == 0.
     */
    OWResult program(uint8_t* romCode);

    /* ── Utilities ────────────────────────────────────────────────────── */
    static uint8_t crc8(const uint8_t* data, uint8_t len);
    static bool    isCompatible(const uint8_t* romCode);
    static void    buildRomCode(const uint8_t* serial6, uint8_t* romCode);
    static void    printRomCode(const uint8_t* romCode);
    static void    printResult(OWResult r);

private:
    uint8_t _pin;
    OneWire _ow;

    /**
     * Wrapper around _ow.reset() that adds a fallback widened-window reset
     * for hardware where the library's fixed 70 µs sample misses the tag's
     * presence pulse.  Also prints diagnostic path information to Serial.
     *
     * The fallback, when triggered, waits the full spec-required 480 µs
     * recovery period from bus release before returning, so the caller can
     * immediately issue commands.
     */
    bool _reset();

    /**
     * RW1990 extended-pulse write bit.  5 ms = '1', 10 ms = '0'.
     * This is the ONLY custom bus operation; all standard 1-Wire slots
     * (reset, write bytes, read bytes) are delegated to the OneWire library.
     */
    void _writeBit(uint8_t bit);
};
