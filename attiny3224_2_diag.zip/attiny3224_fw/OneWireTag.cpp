/**
 * OneWireTag.cpp  —  DS1990 / RW1990 iButton driver
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  WHY THE CUSTOM _readBit() WAS REMOVED
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  A custom _readBit() was added after incorrectly diagnosing that the
 *  OneWire library's read_bit() samples the bus too late at 10 MHz
 *  (~16 µs vs the DS1990's tRDV = 15 µs max).
 *
 *  The diagnosis was wrong.  Evidence:
 *    The custom _readBit() — which sampled at ~11 µs — produced identical
 *    all-0xFF results.  If the sample point were the problem, earlier
 *    sampling would have fixed it.  It didn't.  Therefore the bus is HIGH
 *    at ALL sample times, meaning the tag is not responding to the read
 *    slots at all.  The problem is not in the read; it is upstream.
 *
 *  The OneWire library's read() is correct at 10 MHz:
 *    • _delay_us(3) + _delay_us(10) = 13 µs of deliberate delay
 *    • Plus ~1–2 µs of VPORT register overhead
 *    • Total sample point ≈ 14–15 µs — within tRDV = 15 µs ✓
 *    • The library has been verified on tinyAVR 2-series at 10 MHz
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  ACTUAL ROOT CAUSE OF ALL-0xFF
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  The tag is not responding to read slots because it never received a valid
 *  READ ROM command.  The cause is in the fallback reset recovery timing.
 *
 *  When _ow.reset() returns false and the fallback runs:
 *
 *    Bus released at t = 0
 *    Presence detected (polling loop breaks) at t = 10 µs  ← early break
 *    delayMicroseconds(300)                                  ← 300 µs wait
 *    _ow.write(0x33) starts immediately after return
 *
 *    Total recovery from bus release: 10 + 300 = 310 µs
 *    1-Wire spec requires: >= 480 µs              ← 170 µs SHORT
 *
 *  The tag's internal state machine has not finished its post-reset sequence
 *  when the READ ROM command arrives.  The tag ignores it and sits idle.
 *  All subsequent read slots find the bus at pullup HIGH (no device driving)
 *  and return 0xFF for every byte.
 *
 *  The fix is to never break early from the presence poll — scan the full
 *  480 µs window regardless of when presence is first detected.  This
 *  guarantees both presence detection AND full recovery in one pass.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  WHAT THE ONEWIRE LIBRARY PROVIDES (no reinvention needed)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  reset()       480 µs LOW + presence sample at 70 µs, then 410 µs recovery.
 *                Correctly calibrated to F_CPU via _delay_us().
 *
 *  write(byte)   8 write slots: '1' = 10 µs LOW, '0' = 65 µs LOW.
 *                Both within the DS1990's tLOW1 and tLOW0 specs.
 *
 *  read()        8 read slots: 3 µs LOW start, release, sample at ~13 µs.
 *                Within tRDV = 15 µs max.  Correct and sufficient.
 *
 *  search(addr)  Complete SEARCH ROM algorithm — not replaced here.
 *
 *  The ONLY operation the library cannot perform is the RW1990 write:
 *  5–10 ms programming pulses that are ~100× longer than standard slots.
 *  _writeBit() handles those and nothing else.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  3.3 V OPERATING VOLTAGE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  ATtiny3224 speed grade at 3.3 V: 0–10 MHz (Speed Grade 2, DS40002315).
 *  Set IDE clock to 10 MHz.  All library timing scales automatically.
 *
 *  DS1990 reads at 3.3 V: fully supported (VCC range 2.8–6.0 V).
 *
 *  RW1990 writes at 3.3 V: may be unreliable.  EEPROM charge pump designed
 *  around 5 V.  Consider 2.2 kΩ pullup (~1.5 mA) or a strong-pullup circuit.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  TIMER INTERACTION
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  millis() timer must be TCB0 or TCB1 — NOT TCA0.  megaTinyCore 2.6.x
 *  defaults to TCB1 on ATtiny3224.  Leave it there.
 *
 *  OneWire disables interrupts (~60 µs per bit slot) during timing-critical
 *  sections.  Worst-case millis() skew per READ ROM: ~1 ms.  Inconsequential
 *  for the LED sequencer's 1-second granularity.
 */

#include "OneWireTag.h"
#include <string.h>    /* memcmp, memcpy */

/* ── Constructor ────────────────────────────────────────────────────────── */
OneWireTag::OneWireTag(uint8_t pin) : _pin(pin), _ow(pin) {}

/* ── Read ───────────────────────────────────────────────────────────────── */

OWResult OneWireTag::readRaw(uint8_t* romCode)
{
    if (!_reset()) return OWResult::NO_PRESENCE;

    _ow.write(0x33u);                              /* READ ROM command */

    for (uint8_t i = 0; i < OW_ROM_BYTES; ++i) {
        romCode[i] = _ow.read();                   /* library read, correct at 10 MHz */
    }

    if (OneWire::crc8(romCode, 7) != romCode[7]) return OWResult::CRC_ERROR;
    return OWResult::OK;
}

OWResult OneWireTag::read(uint8_t* romCode)
{
    const OWResult r = readRaw(romCode);
    if (r != OWResult::OK) return r;
    if (!isCompatible(romCode)) return OWResult::WRONG_FAMILY;
    return OWResult::OK;
}

OWResult OneWireTag::scanNext(uint8_t* romCode)
{
    if (!_ow.search(romCode)) return OWResult::NO_PRESENCE;
    if (OneWire::crc8(romCode, 7) != romCode[7]) return OWResult::CRC_ERROR;
    if (!isCompatible(romCode)) return OWResult::WRONG_FAMILY;
    return OWResult::OK;
}

void OneWireTag::resetSearch()
{
    _ow.reset_search();
    delay(1);
}

/* ── Write ──────────────────────────────────────────────────────────────── */

OWResult OneWireTag::write(const uint8_t* romCode, bool useAltCmd)
{
    if (!_reset()) return OWResult::NO_PRESENCE;
    _ow.write(useAltCmd ? RW_CMD_WRITE_ALT : RW_CMD_WRITE);
    delay(RW_ENTER_MS);
    for (uint8_t byte = 0; byte < OW_ROM_BYTES; ++byte) {
        for (uint8_t bit = 0; bit < 8; ++bit) {
            _writeBit((romCode[byte] >> bit) & 0x01u);
        }
    }
    _ow.reset();
    delay(RW_SETTLE_MS);
    return OWResult::OK;
}

/* ── Verify / Program ───────────────────────────────────────────────────── */

OWResult OneWireTag::verify(const uint8_t* expected)
{
    uint8_t actual[OW_ROM_BYTES];
    const OWResult r = readRaw(actual);
    if (r != OWResult::OK) return r;
    if (memcmp(actual, expected, OW_ROM_BYTES) != 0) return OWResult::VERIFY_FAIL;
    return OWResult::OK;
}

OWResult OneWireTag::program(uint8_t* romCode)
{
    if (romCode[7] == 0x00u) romCode[7] = crc8(romCode, 7);
    if (crc8(romCode, 7) != romCode[7]) return OWResult::CRC_ERROR;
    const OWResult wr = write(romCode);
    if (wr != OWResult::OK) return wr;
    return verify(romCode);
}

/* ── Static utilities ───────────────────────────────────────────────────── */

uint8_t OneWireTag::crc8(const uint8_t* data, uint8_t len)
{
    return OneWire::crc8(data, len);
}

bool OneWireTag::isCompatible(const uint8_t* romCode)
{
    return (romCode[0] == OW_FAMILY_DS1990);
}

void OneWireTag::buildRomCode(const uint8_t* serial6, uint8_t* romCode)
{
    romCode[0] = OW_FAMILY_DS1990;
    memcpy(&romCode[1], serial6, 6);
    romCode[7] = crc8(romCode, 7);
}

void OneWireTag::printRomCode(const uint8_t* romCode)
{
    for (uint8_t i = 0; i < OW_ROM_BYTES; ++i) {
        if (romCode[i] < 0x10u) Serial.print('0');
        Serial.print(romCode[i], HEX);
        if (i < OW_ROM_BYTES - 1u) Serial.print(':');
    }
    Serial.println();
}

void OneWireTag::printResult(OWResult r)
{
    switch (r) {
        case OWResult::OK:           Serial.println(F("OK"));           break;
        case OWResult::NO_PRESENCE:  Serial.println(F("NO_PRESENCE"));  break;
        case OWResult::CRC_ERROR:    Serial.println(F("CRC_ERROR"));    break;
        case OWResult::WRONG_FAMILY: Serial.println(F("WRONG_FAMILY")); break;
        case OWResult::VERIFY_FAIL:  Serial.println(F("VERIFY_FAIL"));  break;
        case OWResult::BUS_ERROR:    Serial.println(F("BUS_ERROR"));    break;
        default:                     Serial.println(F("UNKNOWN"));      break;
    }
}

/* ── Private ────────────────────────────────────────────────────────────── */

bool OneWireTag::_reset()
{
    /*
     * PRIMARY PATH — use the library.
     * _ow.reset() is correct at 10 MHz; this path is taken in normal operation.
     * Diagnostic output tells you which path executes on every call.
     */
    if (_ow.reset()) {
        Serial.print(F("OW reset: PRIMARY  "));
        return true;
    }

    /*
     * FALLBACK PATH — widened presence-detection window.
     *
     * Triggered when _ow.reset() misses the presence pulse because its
     * single 70 µs sample point falls just outside the tag's pulse window.
     * This can happen if the ATtiny3224's RC oscillator is running slightly
     * off-frequency at 3.3 V, or if the tag's tPDHIGH is at the 60 µs max
     * end of spec, leaving only ~10 µs margin at the library's sample point.
     *
     * If this path fires consistently, the underlying cause is a hardware
     * timing mismatch.  Solutions in order of preference:
     *   1. Verify Tools → Clock Speed = 10 MHz (not 20 MHz).
     *   2. Check the oscillator calibration fuse (OSCCFG).
     *   3. Try a different tag — some batches have longer tPDHIGH delays.
     *   4. If the fallback is permanently needed, consider this path normal
     *      for this specific hardware pairing and remove the diagnostic print.
     *
     * RECOVERY TIMING (the previous bug):
     * ─────────────────────────────────────
     * The previous implementation broke out of the presence-detection loop
     * as soon as the first LOW was seen, then waited only 300 µs more.
     * With detection at t=10 µs, total recovery = 310 µs — 170 µs short of
     * the 480 µs the spec requires.  The tag was not ready when the READ ROM
     * command arrived, so it ignored it, and all read bytes came back 0xFF.
     *
     * The fix: never break early.  Poll the full 480 µs window.  This
     * simultaneously detects any presence pulse AND guarantees full recovery.
     */
    Serial.print(F("OW reset: FALLBACK "));

    /* Drive reset LOW — 520 µs (10 % margin above 480 µs minimum) */
    noInterrupts();
    pinMode(_pin, OUTPUT);
    digitalWrite(_pin, LOW);
    interrupts();
    delayMicroseconds(520u);

    /* Release bus and scan for presence over the FULL 480 µs recovery window.
     * 48 samples × 10 µs = 480 µs.  Do NOT break early — every microsecond
     * of this loop is also mandatory recovery time for the tag. */
    noInterrupts();
    pinMode(_pin, INPUT);
    interrupts();

    bool present = false;
    for (uint8_t i = 0; i < 48u; ++i) {
        delayMicroseconds(10u);
        if (digitalRead(_pin) == LOW) present = true;   /* note: no break */
    }
    /* 480 µs have now elapsed from bus release; tag is ready for commands. */

    return present;
}

void OneWireTag::_writeBit(uint8_t bit)
{
    /*
     * RW1990 extended-pulse write slot — the ONLY custom bus operation.
     *
     * Standard 1-Wire write slots are 60 µs.  RW1990 EEPROM programming
     * requires 5–10 ms current pulses; the library cannot generate these.
     * All other bus operations (reset, write bytes, read bytes) use the
     * library directly.
     *
     * Interrupts remain ENABLED during delay() so:
     *   • TCB1 millis() tick accumulates normally.
     *   • TCA0 PWM continues driving the LED unaffected.
     *
     * The 5–10 ms pulse has no µs-level timing sensitivity; interrupt
     * latency of a few microseconds is inconsequential.
     */
    pinMode(_pin, OUTPUT);
    digitalWrite(_pin, LOW);
    delay(bit ? RW_PULSE_ONE_MS : RW_PULSE_ZERO_MS);

    pinMode(_pin, INPUT);          /* release — pullup restores idle HIGH */
    delay(RW_RELEASE_MS);
}
