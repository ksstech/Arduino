/**
 * attiny3224_fw.ino  —  ATtiny3224 firmware  |  megaTinyCore 2.6.11
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  WHY Arduino.h AND NOT megaTinyCore.h
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  megaTinyCore is a BOARD SUPPORT PACKAGE (BSP), not a library.  A BSP
 *  provides the Arduino framework for a family of chips; it has no public
 *  header of its own.  The correct entry point is always:
 *
 *      #include <Arduino.h>
 *
 *  When the ATtiny3224 target is selected in the IDE, the compiler resolves
 *  that include to:
 *
 *      {megaTinyCore}/cores/megatinycore/Arduino.h
 *
 *  That file pulls in every megaTinyCore-specific extension automatically:
 *  PIN_PAn / PIN_PBn macros, MEGATINYCORE_VERSION, tinyAVR 2-series register
 *  definitions (VPORT, TCA, TCB, …), analogWrite() split-mode PWM, etc.
 *
 *  There is no "megaTinyCore.h" to include — it does not exist.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  MANDATORY IDE SETTINGS  (Tools menu)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Board                : ATtiny3224 / 3214 / 3204 (megaTinyCore)
 *  Chip                 : ATtiny3224
 *  Clock Source         : 10 MHz internal             ← REQUIRED at 3.3 V; see below
 *  millis()/micros()    : TCB0 or TCB1 (any TCB)      ← must NOT be TCA0
 *  Programmer           : SerialUPDI (HV) via PA0
 *
 *  CLOCK SPEED IS COUPLED TO VCC — tinyAVR 2-series datasheet DS40002315:
 *    0– 5 MHz  at 1.8–5.5 V  (Speed Grade 1)
 *    0–10 MHz  at 2.7–5.5 V  (Speed Grade 2)  ← this board at 3.3 V
 *    0–20 MHz  at 4.5–5.5 V  (Speed Grade 3)
 *
 *  At VCC = 3.3 V, 20 MHz is outside the guaranteed operating envelope.
 *  The chip may appear to run but delayMicroseconds() — a busy-loop scaled
 *  by F_CPU — can mis-time under marginal conditions.  For OneWire this
 *  directly stretches the 70 µs presence-sample delay past the end of the
 *  132 µs presence pulse, causing missed detections and CRC failures.
 *  Select 10 MHz; all timing constants (delayMicroseconds, millis, the
 *  OneWire library) scale automatically via F_CPU — no code changes needed.
 *  PWM frequency becomes: 10 MHz ÷ (64 × 256) ≈ 610 Hz — still adequate.
 *
 *  millis() timer: megaTinyCore 2.6.x defaults to TCB1 on ATtiny3224.
 *  TCB0 also works.  Either is fine.  The only forbidden choice is TCA0:
 *  that prevents split-mode PWM and corrupts OneWire inter-slot timing.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  TIMER ALLOCATION  (ATtiny3224, tinyAVR 2-series)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  TCB1  millis()/micros() — 1 ms periodic interrupt.  Configured by core.
 *        megaTinyCore 2.6.x default on ATtiny3224.  TCB0 also works if
 *        changed in the IDE; either choice leaves TCA0 free for PWM.
 *        TCB1 WO default is PA3; it is OUTPUT-COMPARE-disabled in periodic
 *        mode, so PA3 remains usable as LED GPIO / PWM output.
 *
 *  TCB0  Free.  Reserve for future input-capture, precise pulse timing, or
 *        hardware PWM.  Default WO on PA2.
 *
 *  TCA0  Split mode, fully dedicated to PWM via analogWrite().
 *        10 MHz ÷ (prescaler 64 × 256 counts) ≈ 610 Hz PWM frequency.
 *        Split-mode WO routing for 14-pin package (PB4/PB5 absent):
 *          PORTMUX.TCAROUTEA selects PA-group for WO3–WO5
 *          WO5 → PA5  (HCMP2 / LCMP2, channel 1 in this firmware — LED)
 *          WO3 → PA3  (HCMP0 / LCMP0, channel 0 if a second LED is fitted)
 *          WO4 → PA4  — NOT enabled (PA4 is the 1-Wire bus; enabling WO4
 *                        here would fight the 1-Wire driver).
 *                        Do NOT call analogWrite(PIN_PA4, …).
 *
 *  RTC   Unused.  Reserved for deep-sleep wakeup via 32 kHz internal osc.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  PIN ASSIGNMENT
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  PA0  UPDI      AdaFruit HV Friend SerialUPDI.  Permanently UPDI on
 *                 tinyAVR 2-series; never use as GPIO.
 *
 *  PA2  RELAY     Active-HIGH digital output.  TCA0 WO2 is also on PA2;
 *                 never call analogWrite(PIN_PA2, …).
 *
 *  PA3  LED_AUX   Optional second status LED (hardware PWM WO3 → PA3).
 *                 If not fitted, leave configure(1, …) absent or call stop(1).
 *
 *  PA4  1-WIRE    DS1990 / RW1990 bus.  4.7 kΩ pullup to VCC required.
 *
 *  PA5  LED       Primary status LED, hardware PWM WO5 → PA5.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  REQUIRED LIBRARY  (install via Library Manager)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  No external libraries are required.  The OneWire bus driver is
 *  implemented directly using VPORT registers (see OneWireTag.h for
 *  the explanation of why Paul Stoffregen's OneWire library is
 *  incompatible with the tinyAVR 2-series VPORT register layout).
 */

#include <Arduino.h>
#include "StatusLED.h"
#include "OneWireBus.h"
#include "OneWireTag.h"
#include "DS18Temp.h"

/* ── Pin definitions ────────────────────────────────────────────────────── */
static constexpr uint8_t PIN_LED_PRIMARY = PIN_PA5;
static constexpr uint8_t PIN_LED_AUX     = PIN_PA3;   /* second channel; WO3 */
static constexpr uint8_t PIN_ONEWIRE     = PIN_PA4;
static constexpr uint8_t PIN_RELAY       = PIN_PA2;

/* ── LED: 2-channel instance ────────────────────────────────────────────── */
static const uint8_t kLEDPins[] = { PIN_LED_PRIMARY, PIN_LED_AUX };
StatusLED<2> leds(kLEDPins);

/* ── 1-Wire bus + device drivers ────────────────────────────────────────── */
OneWireBus  owBus(PIN_ONEWIRE);       ///< shared bus driver (VPORT primitives)
OneWireTag  owTag(owBus);             ///< iButton reader/writer
DS18Temp    owTemp(owBus);            ///< DS18xx temperature sensor

/* ── Relay helpers ──────────────────────────────────────────────────────── */
inline void relayOn()  { digitalWrite(PIN_RELAY, HIGH); }
inline void relayOff() { digitalWrite(PIN_RELAY, LOW);  }

/* ══════════════════════════════════════════════════════════════════════════
   Forward declarations
   ══════════════════════════════════════════════════════════════════════════ */
void demoOneWireScan();
void demoDS18Temp();
void demoRelay();

/* ══════════════════════════════════════════════════════════════════════════
   setup()
   ══════════════════════════════════════════════════════════════════════════ */
void setup()
{
    Serial.begin(115200);
    while (!Serial && millis() < 2000) {}
    Serial.println(F("ATtiny3224 init"));
    Serial.print(F("F_CPU = ")); Serial.println(F_CPU);

    /* Relay — de-energise on power-up */
    pinMode(PIN_RELAY, OUTPUT);
    relayOff();

    /* LED channel 0 (PA5) — slow breathing heartbeat, infinite */
    leds.configure(0, LED_INFINITE, 2, 1, 2, 1);

    /* LED channel 1 (PA3) — three blinks then idle */
    leds.configure(1, 3, 0, 1, 0, 1);

    /* DS18xx — detect sensor once at startup (if present) */
    owTemp.detect();
    if (owTemp.result == OWResult::OK) {
        Serial.print(F("DS18: ")); owTemp.printStatus();
    } else {
        Serial.println(F("DS18: not found (will use iButton mode)"));
    }

    Serial.println(F("Setup complete"));
}

/* ══════════════════════════════════════════════════════════════════════════
   loop()
   ══════════════════════════════════════════════════════════════════════════ */
void loop()
{
    leds.update();

    /* Uncomment ONE of the two 1-Wire demos: */
    demoOneWireScan();       /* iButton mode */
    // demoDS18Temp();       /* temperature mode */

    // demoRelay();
}

/* ══════════════════════════════════════════════════════════════════════════
   1-Wire scan — all data lives in owTag.rom / owTag.result
   ══════════════════════════════════════════════════════════════════════════ */
void demoOneWireScan()
{
    static uint32_t lastMs = 0;
    if (millis() - lastMs < 500UL) return;
    lastMs = millis();

    owTag.read();

    /*
     * Everything is now on the instance — no local buffers needed:
     *
     *   owTag.result       — OWResult from the last operation
     *   owTag.rom[0..7]    — ROM code (valid when result == OK)
     *   owTag.timestampMs  — millis() when the operation completed
     *
     * Readable from anywhere: other functions, modules, ISRs.
     */
    Serial.print(F("OW: "));
    OneWireBus::printResult(owTag.result);

    if (owTag.result == OWResult::OK) {
        Serial.print(F("  ROM: "));
        OneWireBus::printRomCode(owTag.rom);
    }

    /* ── Example: program an RW1990 tag ──────────────────────────────── */
    /*
    if (owTag.result == OWResult::OK) {
        const uint8_t serial[6] = { 0x01, 0x23, 0x45, 0x67, 0x89, 0xAB };
        OneWireTag::buildRomCode(serial, owTag.rom);   // populate rom[] directly
        owTag.program();                                // burns rom[], then verifies

        Serial.print(F("Program: "));
        OneWireBus::printResult(owTag.result);
    }
    */
}

/* ══════════════════════════════════════════════════════════════════════════
   LED preset helpers  —  call from anywhere to change LED behaviour
   ══════════════════════════════════════════════════════════════════════════ */

/** Channel 0: slow breath, infinite */
void ledHeartbeat()   { leds.configure(0, LED_INFINITE, 2, 1, 2, 1); }

/** Channel 0: three fast blinks (1 s on, 1 s off) */
void ledError()       { leds.configure(0, 3, 0, 1, 0, 1); }

/** Channel 0: single long pulse */
void ledAck()         { leds.configure(0, 1, 1, 2, 1, 0); }

/** Channel 0: off */
void ledOff()         { leds.configure(0, LED_STOP, 0, 0, 0, 0); }

/** All channels: off */
void ledsAllOff()     { leds.stopAll(); }

/* ══════════════════════════════════════════════════════════════════════════
   DS18xx temperature demo — non-blocking conversion cycle
   ══════════════════════════════════════════════════════════════════════════ */
void demoDS18Temp()
{
    static enum { IDLE, CONVERTING } phase = IDLE;
    static uint32_t lastMs = 0;

    if (owTemp.model == DS18Model::UNKNOWN) return;  /* no sensor detected */

    switch (phase) {
        case IDLE:
            if (millis() - lastMs < 2000UL) return;   /* read every 2 s */
            owTemp.startConversion();
            if (owTemp.result == OWResult::OK) phase = CONVERTING;
            break;

        case CONVERTING:
            if (!owTemp.isReady()) return;             /* still converting */
            owTemp.readTemp();
            lastMs = millis();
            phase  = IDLE;

            if (owTemp.result == OWResult::OK) {
                Serial.print(F("Temp: "));
                Serial.print(owTemp.tempC, 2);
                Serial.println(F(" C"));
            } else {
                Serial.print(F("Temp read: "));
                OneWireBus::printResult(owTemp.result);
            }
            break;
    }
}

/* ══════════════════════════════════════════════════════════════════════════
   DS18xx configuration examples — call from setup() as needed
   ══════════════════════════════════════════════════════════════════════════ */

/** Set 10-bit resolution, alarms at 30 °C high / 5 °C low, save to EEPROM */
void configureTempSensor()
{
    owTemp.setResolution(10);
    owTemp.setAlarms(30, 5);
    owTemp.writeScratchpad();    /* send config to device RAM */
    owTemp.copyScratchpad();     /* persist to device EEPROM  */

    Serial.println(F("Temp sensor configured:"));
    owTemp.printStatus();
}

/* ══════════════════════════════════════════════════════════════════════════
   Relay demonstration
   ══════════════════════════════════════════════════════════════════════════ */
void demoRelay()
{
    static uint32_t lastMs = 0;
    static bool     state  = false;

    if (millis() - lastMs < 5000UL) return;
    lastMs = millis();
    state  = !state;
    state ? relayOn() : relayOff();

    Serial.print(F("Relay: "));
    Serial.println(state ? F("ON") : F("OFF"));
}

/* ══════════════════════════════════════════════════════════════════════════
 * CHANGELOG
 * ══════════════════════════════════════════════════════════════════════════
 *
 * Note: the sketch wires modules together and selects which demo runs; the
 * authoritative per-module history lives in each module's own changelog.
 *
 * 2026-05-29
 *   - Added DS18Temp: instantiated owTemp on the shared bus, detect() in
 *     setup(), non-blocking demoDS18Temp() (startConversion/isReady/readTemp),
 *     and configureTempSensor() example (resolution + alarms + EEPROM save).
 *   - loop() now selects ONE 1-Wire demo at a time: demoOneWireScan()
 *     (iButton, active) vs demoDS18Temp() (temperature, commented out).
 *   - Reworked 1-Wire wiring to the shared-bus model:
 *       OneWireBus owBus(PIN_PA4);   // shared VPORT bus driver
 *       OneWireTag owTag(owBus);     // iButton
 *       DS18Temp   owTemp(owBus);    // temperature
 *     (previously OneWireTag owned the pin directly).
 *   - Static print helpers moved to OneWireBus:: (printResult, printRomCode).
 *
 * Earlier, undated (development sequence, exact times not recorded):
 *   - demoOneWireScan() simplified to the parameterless API: owTag.read()
 *     then read owTag.rom[] / owTag.result directly (no local buffers).
 *   - IDE settings documented in-header: 10 MHz internal clock (3.3 V →
 *     Speed Grade 2), millis()/micros() on any TCB (not TCA0), SerialUPDI
 *     via PA0.
 *   - Timer/pin allocation documented: TCA0 split-mode PWM (WO5→PA5, WO3→PA3);
 *     TCB1 millis() (core default); TCB0 free; PA2 relay GPIO (never
 *     analogWrite on PA2/WO2); PA4 1-Wire (never analogWrite on PA4/WO4).
 *   - StatusLED switched to 2-channel template instance (kLEDPins[]).
 *   - Explained #include <Arduino.h> (not "megaTinyCore.h"): megaTinyCore is
 *     a board package that provides Arduino.h; there is no megaTinyCore.h.
 *   - Original sketch: single status LED on PA5 + DS1990/RW1990 on PA4 +
 *     relay on PA2; loop()-driven StatusLED (no ISR).
 */
