/**
 * OneWireTag.h  —  DS1990 / RW1990 iButton read, write and verify
 *
 * Uses OneWireBus for all standard bus operations.
 * Only the RW1990 extended-pulse write is handled here.
 */

#pragma once
#include "OneWireBus.h"

static constexpr uint8_t OW_FAMILY_DS1990 = 0x01u;

/* RW1990 constants */
static constexpr uint8_t RW_CMD_WRITE     = 0xD1u;
static constexpr uint8_t RW_CMD_WRITE_ALT = 0xC1u;
static constexpr uint8_t RW_PULSE_ONE_MS  = 5u;
static constexpr uint8_t RW_PULSE_ZERO_MS = 10u;
static constexpr uint8_t RW_RELEASE_MS    = 2u;
static constexpr uint8_t RW_ENTER_MS      = 10u;
static constexpr uint8_t RW_SETTLE_MS     = 20u;

class OneWireTag {
public:
    explicit OneWireTag(OneWireBus& bus);

    /* ── Public state ──────────────────────────────────────────────────── */
    uint8_t  rom[OW_ROM_BYTES];
    OWResult result;
    uint32_t timestampMs;

    /* ── Read — results go into rom[] ─────────────────────────────────── */
    OWResult readRaw();
    OWResult read();
    OWResult scanNext();
    void     resetSearch();

    /* ── Write / Program — data taken from rom[] ─────────────────────── */
    OWResult write(bool useAltCmd = false);
    OWResult verify();
    OWResult program();

    /* ── Utilities ────────────────────────────────────────────────────── */
    static bool isCompatible(const uint8_t* romCode);
    static void buildRomCode(const uint8_t* serial6, uint8_t* romCode);

private:
    OneWireBus& _bus;
    OWResult _done(OWResult r);
    void     _writeBitRW(uint8_t bit);
};

/* ══════════════════════════════════════════════════════════════════════════
 * CHANGELOG
 * ══════════════════════════════════════════════════════════════════════════
 *
 * 2026-05-29
 *   - Refactored to take an OneWireBus& reference; all standard bus ops now
 *     delegate to the shared bus.  Only the RW1990 extended-pulse write
 *     (_writeBitRW) remains local.  OWResult / OW_ROM_BYTES now come from
 *     OneWireBus.h.
 *
 * Earlier, undated (development sequence):
 *   - Parameterless API: read/readRaw/scanNext/write/verify/program all
 *     operate on the public rom[] buffer.  Public state reduced to
 *     rom[8] + result + timestampMs (the earlier OWActivity enum / OWState
 *     struct / _record() mechanism was removed as overkill for a single-bus,
 *     single-thread MCU).
 *   - verify() reads the tag into rom[] after saving the expected value, so
 *     rom[] always reflects the tag's actual data afterward (useful on fail).
 *   - Standard bus operations switched from PaulStoffregen/OneWire to direct
 *     VPORT access after the all-0xFF bug (see OneWireBus changelog).
 *   - Original version: DS1990 read + RW1990 write/verify with OWResult
 *     codes (OK / NO_PRESENCE / CRC_ERROR / WRONG_FAMILY / VERIFY_FAIL).
 */
