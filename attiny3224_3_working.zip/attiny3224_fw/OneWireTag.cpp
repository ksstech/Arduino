/**
 * OneWireTag.cpp  —  DS1990 / RW1990 iButton driver
 *                    Direct VPORT implementation for ATtiny3224
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  BUS TIMING SUMMARY (all operations, F_CPU = 10 MHz)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Reset:      520 µs LOW, release, poll presence over full 480 µs recovery.
 *              Tag must respond within 300 µs (tPDHIGH + tPDLOW).
 *
 *  Write '1':  8 µs LOW, release for 62 µs.   (spec: 1–15 µs LOW)
 *  Write '0':  65 µs LOW, release for 5 µs.   (spec: 60–120 µs LOW)
 *
 *  Read:       2 µs LOW start, release, sample at ~10 µs, 55 µs recovery.
 *              Sample is well within tRDV = 15 µs max.
 *
 *  RW1990 write: 5 ms ('1') or 10 ms ('0') LOW, 2 ms release.
 *                Interrupts enabled during delay() — millis()/PWM unaffected.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  CRC8 — DALLAS/MAXIM 1-WIRE (polynomial 0x31, reflected)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Implemented locally; no OneWire library dependency.
 *  A valid ROM code satisfies: crc8(rom, 7) == rom[7].
 */

#include "OneWireTag.h"
#include <string.h>    /* memcmp, memcpy */

/* ── VPORT register offsets ─────────────────────────────────────────────── */
/*  tinyAVR 2-series VPORT layout (each VPORTx is 4 bytes):
 *    +0 = DIR      (direction: 1 = output, 0 = input)
 *    +1 = OUT      (output value when direction = output)
 *    +2 = IN       (read pin state — always, regardless of direction)
 *    +3 = INTFLAGS
 */
static constexpr uint8_t VPORT_DIR = 0;
static constexpr uint8_t VPORT_OUT = 1;
static constexpr uint8_t VPORT_IN  = 2;

/* ── Constructor ────────────────────────────────────────────────────────── */
OneWireTag::OneWireTag(uint8_t pin)
{
    /*
     * Resolve the Arduino pin number to a VPORT base pointer and bitmask.
     * megaTinyCore's digitalPinToPort() returns a port index (0 = PA, 1 = PB).
     * On ATtiny3224:  PIN_PA4 = Arduino pin 0, bit 4 in VPORTA.
     *
     * The VPORT registers are at fixed addresses starting at 0x0000:
     *   VPORTA = 0x0000, VPORTB = 0x0004, ...
     * Each VPORTx block is 4 bytes.
     */
    uint8_t port = digitalPinToPort(pin);
    _vport   = (volatile uint8_t*)(&VPORTA) + (port * 4u);
    _bitmask = digitalPinToBitMask(pin);

    /* Start as input; external pullup holds bus HIGH */
    _vport[VPORT_DIR] &= ~_bitmask;
}

/* ══════════════════════════════════════════════════════════════════════════
   Low-level bus operations — all using VPORT directly
   ══════════════════════════════════════════════════════════════════════════ */

bool OneWireTag::_reset()
{
    /* Ensure bus is released before starting */
    _vport[VPORT_DIR] &= ~_bitmask;
    delayMicroseconds(10);

    /* Drive bus LOW for 520 µs (>= 480 µs minimum reset pulse) */
    noInterrupts();
    _vport[VPORT_OUT] &= ~_bitmask;       /* OUT = 0 (will drive LOW) */
    _vport[VPORT_DIR] |=  _bitmask;        /* DIR = output → bus goes LOW */
    interrupts();
    delayMicroseconds(520);

    /* Release bus and poll for presence over the FULL 480 µs recovery.
     * Do NOT break early — the full 480 µs is mandatory recovery time. */
    noInterrupts();
    _vport[VPORT_DIR] &= ~_bitmask;        /* DIR = input → pullup restores HIGH */
    interrupts();

    bool present = false;
    for (uint8_t i = 0; i < 48u; ++i) {
        delayMicroseconds(10);
        if (!(_vport[VPORT_IN] & _bitmask)) present = true;   /* no break */
    }
    return present;
}

void OneWireTag::_writeBit(uint8_t bit)
{
    if (bit & 1) {
        /* Write '1': short LOW (8 µs), then release for rest of slot */
        noInterrupts();
        _vport[VPORT_OUT] &= ~_bitmask;
        _vport[VPORT_DIR] |=  _bitmask;
        delayMicroseconds(8);
        _vport[VPORT_DIR] &= ~_bitmask;
        interrupts();
        delayMicroseconds(62);
    } else {
        /* Write '0': long LOW (65 µs), then brief release */
        noInterrupts();
        _vport[VPORT_OUT] &= ~_bitmask;
        _vport[VPORT_DIR] |=  _bitmask;
        delayMicroseconds(65);
        _vport[VPORT_DIR] &= ~_bitmask;
        interrupts();
        delayMicroseconds(5);
    }
}

uint8_t OneWireTag::_readBit()
{
    uint8_t r;
    noInterrupts();
    _vport[VPORT_OUT] &= ~_bitmask;
    _vport[VPORT_DIR] |=  _bitmask;       /* drive LOW — start of read slot */
    delayMicroseconds(2);
    _vport[VPORT_DIR] &= ~_bitmask;       /* release — tag may now drive */
    delayMicroseconds(8);
    r = (_vport[VPORT_IN] & _bitmask) ? 1u : 0u;   /* sample at ~10 µs */
    interrupts();
    delayMicroseconds(55);                 /* complete slot (~65 µs total) */
    return r;
}

void OneWireTag::_writeByte(uint8_t byte)
{
    for (uint8_t bit = 0; bit < 8u; ++bit) {
        _writeBit((byte >> bit) & 1u);     /* LSB first */
    }
}

uint8_t OneWireTag::_readByte()
{
    uint8_t byte = 0;
    for (uint8_t bit = 0; bit < 8u; ++bit) {
        byte |= (_readBit() << bit);       /* LSB first */
    }
    return byte;
}

/* ── RW1990 extended-pulse write bit ────────────────────────────────────── */

void OneWireTag::_writeBitRW(uint8_t bit)
{
    /*
     * 5 ms LOW = '1', 10 ms LOW = '0'.
     * Interrupts enabled during delay() so millis() and PWM continue.
     */
    _vport[VPORT_OUT] &= ~_bitmask;
    _vport[VPORT_DIR] |=  _bitmask;
    delay(bit ? RW_PULSE_ONE_MS : RW_PULSE_ZERO_MS);

    _vport[VPORT_DIR] &= ~_bitmask;       /* release — pullup restores HIGH */
    delay(RW_RELEASE_MS);
}

/* ══════════════════════════════════════════════════════════════════════════
   Public API
   ══════════════════════════════════════════════════════════════════════════ */

OWResult OneWireTag::readRaw(uint8_t* romCode)
{
    if (!_reset()) return OWResult::NO_PRESENCE;
    _writeByte(0x33u);                                 /* READ ROM */
    for (uint8_t i = 0; i < OW_ROM_BYTES; ++i) {
        romCode[i] = _readByte();
    }
    if (crc8(romCode, 7) != romCode[7]) return OWResult::CRC_ERROR;
    return OWResult::OK;
}

OWResult OneWireTag::read(uint8_t* romCode)
{
    const OWResult r = readRaw(romCode);
    if (r != OWResult::OK) return r;
    if (!isCompatible(romCode)) return OWResult::WRONG_FAMILY;
    return OWResult::OK;
}

OWResult OneWireTag::scanNext(uint8_t* romCode)
{
    /*
     * Simplified single-pass SEARCH ROM (0xF0) for one tag.
     * For multi-tag enumeration a full search-tree algorithm is needed;
     * for iButton readers (one contact at a time) this covers the use case.
     */
    if (!_reset()) return OWResult::NO_PRESENCE;
    _writeByte(0xF0u);                                 /* SEARCH ROM */

    for (uint8_t i = 0; i < OW_ROM_BYTES; ++i) {
        uint8_t byte = 0;
        for (uint8_t b = 0; b < 8; ++b) {
            uint8_t bit    = _readBit();               /* true ID bit */
            uint8_t bitCmp = _readBit();               /* complement */
            if (bit && bitCmp) return OWResult::NO_PRESENCE; /* no device */
            _writeBit(bit);                            /* select direction */
            byte |= (bit << b);
        }
        romCode[i] = byte;
    }

    if (crc8(romCode, 7) != romCode[7]) return OWResult::CRC_ERROR;
    if (!isCompatible(romCode)) return OWResult::WRONG_FAMILY;
    return OWResult::OK;
}

void OneWireTag::resetSearch()
{
    /* No persistent search state needed for single-pass implementation */
    delay(1);
}

/* ── Write / Verify / Program ───────────────────────────────────────────── */

OWResult OneWireTag::write(const uint8_t* romCode, bool useAltCmd)
{
    if (!_reset()) return OWResult::NO_PRESENCE;

    _writeByte(useAltCmd ? RW_CMD_WRITE_ALT : RW_CMD_WRITE);
    delay(RW_ENTER_MS);

    for (uint8_t byte = 0; byte < OW_ROM_BYTES; ++byte) {
        for (uint8_t bit = 0; bit < 8; ++bit) {
            _writeBitRW((romCode[byte] >> bit) & 0x01u);
        }
    }

    _reset();                  /* exit write mode */
    delay(RW_SETTLE_MS);       /* EEPROM burn time */
    return OWResult::OK;
}

OWResult OneWireTag::verify(const uint8_t* expected)
{
    uint8_t actual[OW_ROM_BYTES];
    const OWResult r = readRaw(actual);
    if (r != OWResult::OK) return r;
    if (memcmp(actual, expected, OW_ROM_BYTES) != 0) return OWResult::VERIFY_FAIL;
    return OWResult::OK;
}

OWResult OneWireTag::program(uint8_t* romCode)
{
    if (romCode[7] == 0x00u) romCode[7] = crc8(romCode, 7);
    if (crc8(romCode, 7) != romCode[7]) return OWResult::CRC_ERROR;
    const OWResult wr = write(romCode);
    if (wr != OWResult::OK) return wr;
    return verify(romCode);
}

/* ══════════════════════════════════════════════════════════════════════════
   CRC8 — Dallas/Maxim 1-Wire (polynomial 0x31, reflected, init 0x00)
   ══════════════════════════════════════════════════════════════════════════ */

uint8_t OneWireTag::crc8(const uint8_t* data, uint8_t len)
{
    uint8_t crc = 0x00u;
    for (uint8_t i = 0; i < len; ++i) {
        uint8_t byte = data[i];
        for (uint8_t bit = 0; bit < 8u; ++bit) {
            const uint8_t mix = (crc ^ byte) & 0x01u;
            crc >>= 1;
            if (mix) crc ^= 0x8Cu;
            byte >>= 1;
        }
    }
    return crc;
}

/* ══════════════════════════════════════════════════════════════════════════
   Static utilities
   ══════════════════════════════════════════════════════════════════════════ */

bool OneWireTag::isCompatible(const uint8_t* romCode)
{
    return (romCode[0] == OW_FAMILY_DS1990);
}

void OneWireTag::buildRomCode(const uint8_t* serial6, uint8_t* romCode)
{
    romCode[0] = OW_FAMILY_DS1990;
    memcpy(&romCode[1], serial6, 6);
    romCode[7] = crc8(romCode, 7);
}

void OneWireTag::printRomCode(const uint8_t* romCode)
{
    for (uint8_t i = 0; i < OW_ROM_BYTES; ++i) {
        if (romCode[i] < 0x10u) Serial.print('0');
        Serial.print(romCode[i], HEX);
        if (i < OW_ROM_BYTES - 1u) Serial.print(':');
    }
    Serial.println();
}

void OneWireTag::printResult(OWResult r)
{
    switch (r) {
        case OWResult::OK:           Serial.println(F("OK"));           break;
        case OWResult::NO_PRESENCE:  Serial.println(F("NO_PRESENCE"));  break;
        case OWResult::CRC_ERROR:    Serial.println(F("CRC_ERROR"));    break;
        case OWResult::WRONG_FAMILY: Serial.println(F("WRONG_FAMILY")); break;
        case OWResult::VERIFY_FAIL:  Serial.println(F("VERIFY_FAIL"));  break;
        case OWResult::BUS_ERROR:    Serial.println(F("BUS_ERROR"));    break;
        default:                     Serial.println(F("UNKNOWN"));      break;
    }
}
