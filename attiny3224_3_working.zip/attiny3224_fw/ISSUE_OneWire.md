# GitHub Issue — PaulStoffregen/OneWire
# URL: https://github.com/PaulStoffregen/OneWire/issues/new
# ─────────────────────────────────────────────────────────────

## Title

OneWire broken on tinyAVR 2-series (ATtiny3224) — classic AVR register offsets used instead of VPORT/modern-AVR layout

## Labels

bug

## Body (paste below this line)
────────────────────────────────────────────────────────────────

### Summary

The OneWire library is non-functional on the tinyAVR 2-series (tested on ATtiny3224 with megaTinyCore 2.6.11). `reset()` never detects a device, `write()` and `read()` operate on wrong registers. A manual VPORT implementation on the same pin and hardware reads tags correctly.

### Root Cause

In `util/OneWire_direct_gpio.h`, the `#if defined(__AVR__)` block has a special case for `__AVR_ATmega4809__` (megaAVR 0-series, with correct PORT register offsets −8 and −4) and a fallback `#else` using classic ATmega offsets +1 and +2:

```cpp
#if defined(__AVR_ATmega4809__)
  #define DIRECT_MODE_OUTPUT(base, mask)  ((*((base)-8)) |= (mask))   // ✓ PORT.IN → PORT.DIR
  #define DIRECT_WRITE_LOW(base, mask)    ((*((base)-4)) &= ~(mask))  // ✓ PORT.IN → PORT.OUT
#else
  #define DIRECT_MODE_OUTPUT(base, mask)  ((*((base)+1)) |= (mask))   // ✗ on modern AVR
  #define DIRECT_WRITE_LOW(base, mask)    ((*((base)+2)) &= ~(mask))  // ✗ on modern AVR
#endif
```

The tinyAVR 0/1/2-series and AVR DA/DB/DD-series share the same PORT/VPORT peripheral layout as the ATmega4809, but are **not** matched by `__AVR_ATmega4809__`. They fall into the `#else` branch.

On these chips, `portInputRegister()` returns a pointer to the VPORT IN register. The VPORT layout is:

```
Offset 0 = DIR
Offset 1 = OUT
Offset 2 = IN     ← base points here (portInputRegister)
Offset 3 = INTFLAGS
```

With base = `&VPORTx.IN`:
| Macro | Offset | Lands on | Expected |
|---|---|---|---|
| `DIRECT_READ` | `*(base)` | VPORTx.IN | VPORTx.IN ✓ |
| `DIRECT_MODE_OUTPUT` | `*(base+1)` | VPORTx.INTFLAGS | VPORTx.DIR ✗ |
| `DIRECT_WRITE_LOW` | `*(base+2)` | Next VPORTy.DIR | VPORTx.OUT ✗ |

The library writes direction changes to the interrupt flags register and output values to a different port's direction register. No valid bus signals are ever produced.

### Affected Chips

All modern AVR families except ATmega4809:
- **tinyAVR 0-series**: ATtiny202/402/204/404/804/1604/406/806/1606/807/1607
- **tinyAVR 1-series**: ATtiny212/412/214/414/814/1614/416/816/1616/3216/417/817/1617/3217
- **tinyAVR 2-series**: ATtiny424/824/1624/3224/426/826/1626/3226/427/827/1627/3227
- **AVR DA/DB/DD/EA-series**: AVR128DA, AVR128DB, AVR64DD, etc.

### Reproduction

**Hardware**: ATtiny3224 on custom board, PA4 as 1-Wire bus with 4.7 kΩ pullup to 3.3 V, DS1990A iButton.

**Software**: megaTinyCore 2.6.11, OneWire 2.3.8 (latest from Library Manager), 10 MHz internal clock.

**Test result** (using a diagnostic sketch that tests both the library and direct VPORT access):

```
OneWire library: ow.reset() returned false for 30 seconds straight
                 0/5 rapid resets succeeded
                 All reads return 0xFF

Manual VPORT:    Presence detected immediately
                 ROM: 01:4E:BB:2A:04:00:00:91
                 CRC: PASS
```

Same pin, same hardware, same tag. The library fails; direct VPORT access works.

### Proposed Fix

SpenceKonde's PR #94 (opened August 2020) addresses this exact issue by detecting all modern AVR architectures and using VPORT register access. It has been open for 5+ years.

The minimal fix for `OneWire_direct_gpio.h` is to broaden the ATmega4809 detection to cover all modern AVR chips. One approach:

```cpp
// Replace:
#if defined(__AVR_ATmega4809__)

// With:
#if defined(MEGATINYCORE) || defined(DXCORE) || defined(__AVR_ATmega4809__) || \
    defined(__AVR_ATmega4808__) || defined(__AVR_ATmega3209__) || \
    defined(__AVR_ATmega3208__) || defined(__AVR_ATmega1609__) || \
    defined(__AVR_ATmega1608__) || defined(__AVR_ATmega809__)  || \
    defined(__AVR_ATmega808__)
```

Or, more robustly, detect by architecture:

```cpp
#if (__AVR_ARCH__ >= 100)
```

(`__AVR_ARCH__` is 102/103/104 for all modern AVR parts, versus 2–6 for classic ATmega/ATtiny.)

The ideal fix (as in PR #94) uses VPORT registers directly for single-cycle atomic I/O, but even the minimal `#if` change above would make the library functional on all modern AVR chips.

### Environment

- **Chip**: ATtiny3224 (14-pin, tinyAVR 2-series)
- **Core**: megaTinyCore 2.6.11
- **OneWire version**: 2.3.8 (Library Manager), master branch as of 2026-05-27
- **Arduino IDE**: 2.x
- **VCC**: 3.3 V, Clock: 10 MHz internal
- **Tag**: DS1990A (family 0x01), also tested with RW1990

### Related

- PR #94 by @SpenceKonde — "Add support for the rest of the megaAVR 0-series, the tinyAVR 0/1-series, and the new AVR Dx-series, make interrupt safe" (opened 2020-08-10, still open)
- Issue #64 — "Doesn't work on xMega, Mega-0 or 'XTiny' AVRs" (2018)
