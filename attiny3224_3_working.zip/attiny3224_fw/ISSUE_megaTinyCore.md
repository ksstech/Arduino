# GitHub Issue — SpenceKonde/megaTinyCore
# URL: https://github.com/SpenceKonde/megaTinyCore/issues/new
# ─────────────────────────────────────────────────────────────

## Title

OneWire library (PaulStoffregen) silently broken on tinyAVR 2-series — PR #94 never merged, library uses classic AVR register offsets

## Labels

bug, documentation, third-party-library

## Body (paste below this line)
────────────────────────────────────────────────────────────────

### Summary

The mainline OneWire library by Paul Stoffregen (v2.3.8, current Library Manager release) is silently non-functional on all tinyAVR 0/1/2-series chips with megaTinyCore. `ow.reset()` never returns true, reads always return 0xFF. There is no compile-time warning.

This was identified and a fix submitted as PR PaulStoffregen/OneWire#94 by @SpenceKonde in August 2020. That PR has not been merged as of May 2026 (5+ years).

### Impact

Any megaTinyCore user who installs OneWire from the Arduino Library Manager and attempts to use it for DS18B20 temperature sensors, DS1990 iButtons, or any other 1-Wire device will get silent failures. The library compiles cleanly, `reset()` appears to execute, but no bus signals are produced on the correct pin.

### Technical Details

`OneWire_direct_gpio.h` has a special case for `__AVR_ATmega4809__` with correct PORT register offsets (−8 for DIR, −4 for OUT from the IN register). All other `__AVR__` targets use classic ATmega offsets (+1, +2) which assume the `PINx/DDRx/PORTx` register layout.

The tinyAVR series shares the same modern PORT/VPORT peripheral as the ATmega4809 but is not matched by `__AVR_ATmega4809__`. The `portInputRegister()` on megaTinyCore returns a VPORT address where the layout is `DIR(+0) / OUT(+1) / IN(+2)`. The classic +1/+2 offsets from IN land on `INTFLAGS` and the next VPORT's DIR — completely wrong registers.

### Diagnostic Evidence

Tested on ATtiny3224, megaTinyCore 2.6.11, PA4 with DS1990A:

```
OneWire library (ow.reset()):     30 seconds of failures, 0/5 resets
Direct VPORTA bit-bang (same pin): Instant detection, ROM: 01:4E:BB:2A:04:00:00:91, CRC PASS
```

A diagnostic also revealed the pin numbering:
```
PIN_PA4 = 0   (not 4)
PIN_PA5 = 1
PIN_PA3 = 10
```

The non-obvious pin mapping is correct (megaTinyCore's own `digitalPinToBitMask()` resolves correctly) — the issue is solely in the OneWire library's register offset arithmetic.

### Suggested Actions

1. **Documentation**: Add a note to `LibraryCompatibility.md` that OneWire (PaulStoffregen) is broken on tinyAVR 0/1/2-series and list the workaround (use OneWireNg, or a direct VPORT implementation).

2. **PR #94 follow-up**: Consider whether megaTinyCore should ship a bundled/patched OneWire library (as it does for Wire, SPI, etc.) since upstream appears unresponsive to PR #94.

3. **Alternatively**: If megaTinyCore's `portInputRegister()` could be made to return an address that is compatible with the ATmega4809 offsets (−8, −4), the existing ATmega4809 branch would work for tinyAVR too. However, this might break other assumptions.

### Environment

- **Chip**: ATtiny3224 (14-pin, tinyAVR 2-series)
- **Core**: megaTinyCore 2.6.11
- **OneWire version**: 2.3.8 (Library Manager)
- **IDE**: Arduino IDE 2.x
- **VCC**: 3.3 V, Clock: 10 MHz internal

### Related

- PaulStoffregen/OneWire PR #94 — your fix for this exact issue, submitted 2020-08-10
- PaulStoffregen/OneWire Issue #64 — original report from 2018
- A corresponding issue has been filed on PaulStoffregen/OneWire with full register-level analysis
