/**
 * OneWireTag.h  —  DS1990 / RW1990 iButton read, write and verify
 *                  for ATtiny3224 / megaTinyCore 2.6.x
 *
 * SUPPORTED TAGS
 * ──────────────
 *  Family 0x01   DS1990A, DS1990R  (read-only serial number)
 *                RW1990, RW1990.1  (writable, command 0xD1)
 *                RW1990.2          (writable, may need alternate command 0xC1)
 *
 * HARDWARE
 * ────────
 *  PA4 → 1-Wire bus, 4.7 kΩ pullup to VCC (3.3 V) required.
 *  At 3.3 V this gives ~0.7 mA — adequate for DS1990 reads.
 *  For RW1990 write reliability consider 2.2 kΩ (~1.5 mA) or a strong-
 *  pullup circuit; see 3.3 V section in OneWireTag.cpp for full options.
 */

#pragma once
#include <Arduino.h>
#include <OneWire.h>

/* ── Bus constants ──────────────────────────────────────────────────────── */
static constexpr uint8_t OW_ROM_BYTES     = 8u;
static constexpr uint8_t OW_FAMILY_DS1990 = 0x01u;

/* ── RW1990 proprietary write constants ─────────────────────────────────── */
static constexpr uint8_t RW_CMD_WRITE     = 0xD1u;   ///< write-enable, most units
static constexpr uint8_t RW_CMD_WRITE_ALT = 0xC1u;   ///< alternate for some RW1990.2 lots
static constexpr uint8_t RW_PULSE_ONE_MS  = 5u;      ///< LOW pulse width for logic '1'
static constexpr uint8_t RW_PULSE_ZERO_MS = 10u;     ///< LOW pulse width for logic '0'
static constexpr uint8_t RW_RELEASE_MS    = 2u;      ///< HIGH (release) between bits
static constexpr uint8_t RW_ENTER_MS      = 10u;     ///< wait after write-enable cmd
static constexpr uint8_t RW_SETTLE_MS     = 20u;     ///< wait after last bit for EEPROM

/* ── Result / error codes ───────────────────────────────────────────────── */
/**
 * Granular result codes returned by all read/write operations.
 * Use these for diagnostics rather than inferring failure from a bool.
 */
enum class OWResult : uint8_t {
    OK            = 0,  ///< Success
    NO_PRESENCE   = 1,  ///< Reset sent; no presence pulse detected
    CRC_ERROR     = 2,  ///< Data received but CRC mismatch
    WRONG_FAMILY  = 3,  ///< ROM[0] is not a recognised DS1990/RW1990 family byte
    VERIFY_FAIL   = 4,  ///< Read-back after write did not match expected ROM
    BUS_ERROR     = 5,  ///< Unexpected bus state during write
};

/* ── OneWireTag class ───────────────────────────────────────────────────── */
class OneWireTag {
public:
    /**
     * Initialise with the 1-Wire bus pin (use PIN_PA4).
     * The pin is set to INPUT; the external 4.7 kΩ pullup holds it HIGH.
     */
    explicit OneWireTag(uint8_t pin);

    /* ── Read ─────────────────────────────────────────────────────────── */

    /**
     * Read the ROM code from the single tag on the bus (READ ROM 0x33).
     * Use only when exactly one tag is present at a time.
     *
     * On success OWResult::OK, romCode[0..7] is populated and CRC is valid.
     * On any error the raw bytes received are still placed in romCode so the
     * caller can inspect them for diagnostics.
     *
     * @param romCode  Output buffer, must be OW_ROM_BYTES (8) bytes.
     * @return OWResult code — check for OWResult::OK before trusting data.
     */
    OWResult read(uint8_t* romCode);

    /**
     * Scan for the next tag via SEARCH ROM (multiple-tag enumeration).
     * Call resetSearch() before the first scan in a new pass.
     *
     * @param romCode  Output buffer, OW_ROM_BYTES bytes.
     * @return OWResult::OK if a tag was found with valid CRC; else error code.
     */
    OWResult scanNext(uint8_t* romCode);

    /** Reset SEARCH ROM state so scanNext() starts from the first tag. */
    void resetSearch();

    /* ── Write (RW1990 only) ──────────────────────────────────────────── */

    /**
     * Write a new ROM code to an RW1990 tag using extended-pulse programming.
     * The tag must be the ONLY device on the bus during programming.
     * Always follow this with verify() or use program() which does both.
     *
     * @param romCode   8 bytes to burn; romCode[7] must be a valid CRC.
     * @param useAltCmd Pass true to use command 0xC1 (some RW1990.2 lots).
     * @return OWResult::OK if the write sequence completed without bus error.
     */
    OWResult write(const uint8_t* romCode, bool useAltCmd = false);

    /* ── Verify ───────────────────────────────────────────────────────── */

    /**
     * Read back and compare the tag ROM to 'expected'.
     * @return OWResult::OK if read succeeded AND data matches byte-for-byte.
     */
    OWResult verify(const uint8_t* expected);

    /* ── Combined program ─────────────────────────────────────────────── */

    /**
     * Write then verify in one call.
     * If romCode[7] == 0 the CRC byte is computed and filled in automatically.
     *
     * @param romCode  8-byte buffer; byte 7 updated in-place if it was 0.
     * @return OWResult::OK only if write succeeded AND verify confirmed match.
     */
    OWResult program(uint8_t* romCode);

    /* ── Static utilities ─────────────────────────────────────────────── */

    /**
     * Compute Dallas/Maxim 1-Wire CRC8 (polynomial 0x31).
     * A valid ROM satisfies: crc8(romCode, 7) == romCode[7]
     */
    static uint8_t    crc8(const uint8_t* data, uint8_t len);

    /** True if romCode[0] is a recognised DS1990 / RW1990 family byte. */
    static bool       isCompatible(const uint8_t* romCode);

    /**
     * Build a complete 8-byte ROM from 6 serial bytes.
     * Sets romCode[0] = 0x01 (family), copies 6 serial bytes, fills CRC.
     */
    static void       buildRomCode(const uint8_t* serial6, uint8_t* romCode);

    /** Print romCode to Serial as "01:23:45:67:89:AB:CD:EF\n". */
    static void       printRomCode(const uint8_t* romCode);

    /** Print an OWResult code as a human-readable string to Serial. */
    static void       printResult(OWResult r);

    /**
     * Diagnostic read: returns raw bytes and OWResult regardless of CRC.
     * Use to inspect exactly what was received when CRC_ERROR is reported.
     */
    OWResult readRaw(uint8_t* romCode);

private:
    uint8_t _pin;
    uint8_t _portBitmask;   ///< PA4 bitmask in VPORTA, computed once at construction
    OneWire _ow;

    /**
     * Robust reset: tries _ow.reset() first; falls back to a manually-widened
     * presence-detection window if the library's fixed 70 µs sample point
     * misses the tag's presence pulse.
     * @return true if a presence pulse was detected by either method.
     */
    bool _reset();

    /**
     * Read one bit using direct VPORTA access and compile-time _delay_us().
     *
     * WHY NOT _ow.read():
     * OneWire::read_bit() contains ~15 cycles of function-call and pin-setup
     * overhead in addition to its delayMicroseconds(3) + delayMicroseconds(10)
     * delays.  At 10 MHz those extra cycles consume an additional ~1.5 µs
     * versus 20 MHz, pushing the total from slot-start to sample to ~16–17 µs.
     * The DS1990 only guarantees data valid for 15 µs from the slot-start
     * falling edge (tRDV = 15 µs max), so every bit is sampled after the tag
     * has released its zero-bit LOW → all bits read HIGH → 0xFF for all bytes.
     *
     * This implementation uses single-cycle VPORTA register writes (no
     * function-call overhead) and _delay_us() compile-time constants to
     * achieve a sample point of ≈ 11 µs at any F_CPU, well within tRDV.
     *
     * NOTE: VPORTA is hardcoded because PA4 is on Port A of the ATtiny3224.
     * If porting to a different pin or device, update the register name.
     */
    uint8_t _readBit();

    /**
     * Read one full byte LSB-first using _readBit().
     */
    uint8_t _readByte();

    /**
     * Write one bit to an RW1990 tag using extended-pulse timing.
     * 5 ms LOW = logic '1',  10 ms LOW = logic '0'.
     * Interrupts remain enabled; millis() continues normally.
     */
    void _writeBit(uint8_t bit);
};
