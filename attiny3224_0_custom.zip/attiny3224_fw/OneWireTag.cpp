/**
 * OneWireTag.cpp  —  DS1990 / RW1990 iButton driver
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  ROOT CAUSE ANALYSIS — 132 µs LOW OBSERVED, TAG NOT DETECTED
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  The 132 µs LOW you measured is the DS1990 PRESENCE PULSE (valid range
 *  60–240 µs per datasheet).  The master's 480 µs reset LOW precedes it
 *  on the bus.  The tag IS correctly responding to the reset.
 *
 *  The presence pulse being detected means the reset IS long enough.
 *  The failure occurs AFTER reset — either during READ ROM or in CRC/family
 *  validation.  Two systematic root causes have been identified:
 *
 *  1. PRESENCE SAMPLING WINDOW (most likely)
 *  ─────────────────────────────────────────
 *  After releasing the reset LOW, the OneWire library waits exactly 70 µs
 *  then takes a single-point sample.  If delayMicroseconds(70) runs
 *  slightly long due to a clock miscalibration, the sample may land after
 *  the 132 µs presence pulse has already ended — making reset() return 0
 *  (no device) even though the tag responded.
 *
 *  The _reset() wrapper in this file adds a 150 µs sliding window that
 *  samples every 10 µs.  Any falling edge within the window constitutes
 *  a valid presence.
 *
 *  The clock miscalibration source: if the IDE "Clock Speed" menu selection
 *  does not match the actual oscillator fuse setting, delayMicroseconds()
 *  (which uses a busy loop scaled by F_CPU) will be systematically early
 *  or late.  Verify:  Tools → Clock Speed → matches your fuse/OSCCFG value.
 *  The ATtiny3224 default OSCCFG fuse = 0b00 → 20 MHz oscillator selected.
 *  megaTinyCore startup code disables the /6 prescaler set by the factory,
 *  so F_CPU should equal the oscillator frequency chosen in the IDE.
 *
 *  2. millis() TIMER CONFLICT (secondary)
 *  ───────────────────────────────────────
 *  If the millis() timer is left on TCA0 (Arduino IDE default on some cores),
 *  then analogWrite() repurposes TCA0 split mode for PWM, which changes
 *  TCA0's overflow interrupt period.  The now-faster interrupts fire between
 *  consecutive OneWire bit slots (OneWire uses cli/sei per slot, not across
 *  slots) and extend the inter-slot recovery time, corrupting bit reads.
 *  This causes CRC failures even when reset() succeeds.
 *
 *  FIX:  Tools → millis()/micros() → any TCB (TCB0 or TCB1; NOT TCA0)
 *        megaTinyCore 2.6.x defaults to TCB1 on ATtiny3224 — leave it there.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  LIBRARY SELECTION
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Candidate                 Decision    Reasoning
 *  ─────────────────────     ────────    ──────────────────────────────────
 *  OneWire (Stoffregen)      CHOSEN      Universal 1-Wire bus layer with
 *    v2.3.7+                             AVR-tuned delayMicroseconds timing.
 *                                        v2.3.7 added tinyAVR 2-series VPORT
 *                                        register support used by megaTinyCore.
 *                                        Includes CRC8 helper.
 *                                        CON: single 70 µs sample point for
 *                                        presence; mitigated by _reset() here.
 *
 *  DallasTemperature         REJECTED    Targets DS18B20 temp sensors; no
 *                                        benefit for ROM-only iButton work.
 *
 *  Custom bit-bang            PARTIAL    Used only for RW1990 write bits
 *  (this file, _writeBit)                (5–10 ms pulses) that are outside
 *                                        the standard 60 µs slot window.
 *                                        All standard bus ops use OneWire.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  3.3 V OPERATING VOLTAGE — IMPACT ANALYSIS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  ATtiny3224 — clock speed constraint at 3.3 V.
 *    The tinyAVR 2-series datasheet defines Speed Grade 2 as 0–10 MHz at
 *    2.7–5.5 V.  20 MHz requires VCC ≥ 4.5 V (Speed Grade 3).  At 3.3 V,
 *    set the IDE clock to 10 MHz.  delayMicroseconds() and all OneWire
 *    slot timing scale via F_CPU automatically; no code changes are needed.
 *
 *  DS1990 reads at 3.3 V — fully supported.
 *    The DS1990A/R datasheet specifies VCC = 2.8–6.0 V.  A 4.7 kΩ pullup
 *    to 3.3 V supplies ~0.7 mA, which is within the bus current budget for
 *    read operations.  Reset and presence-pulse timing is voltage-independent
 *    (it depends only on the MCU oscillator, not on VCC).
 *
 *  RW1990 writes at 3.3 V — UNRELIABLE on many units.
 *    The RW1990 stores data in an EEPROM cell that requires a minimum
 *    programming voltage.  The internal charge pump on most RW1990 variants
 *    is designed around a 5 V supply.  At 3.3 V:
 *      • Some units (particularly newer small-die variants) program correctly.
 *      • Many units (especially older or generic lots) fail silently:
 *        write() returns OK, verify() returns VERIFY_FAIL.
 *    If writes are required and the supply cannot be raised:
 *      Option A — Lower the pullup to 2.2 kΩ: increases write current to
 *                 ~1.5 mA, which sometimes helps marginal units at 3.3 V.
 *      Option B — Add a P-channel MOSFET or PNP strong-pullup driven by a
 *                 GPIO (e.g. PA3 when it is not used as LED channel 1) to
 *                 supply >10 mA during the write pulse; some datasheets
 *                 recommend this even at 5 V for reliable programming.
 *      Option C — Source tags rated for 3.3 V operation (some RW1990.2
 *                 batches from specific suppliers specify VCC_min = 3.0 V).
 *    The firmware itself requires no change; the write timing and protocol
 *    are identical at any supply voltage.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  TIMER / INTERRUPT INTERACTION
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  OneWire::reset()   — cli/sei around the 480 µs reset + 70 µs sample only.
 *                       410 µs tail runs with interrupts enabled.
 *  _readBit()        — cli/sei around each ~11 µs read slot (replaces _ow.read()).
 *  OneWire::write()  — cli/sei around each individual 60 µs write slot.
 *  _writeBit()       — interrupts enabled; delay() used for 5–10 ms pulses.
 *
 *  Each READ ROM call = 1 reset + 64 _readBit() slots ≈ 5–6 ms total.
 *  Worst-case millis() skew per read = one missed TCB compare = 1 ms.
 *  This is inconsequential for the LED sequencer's 1-second granularity.
 */

#include "OneWireTag.h"
#include <util/delay.h>    /* _delay_us(): compile-time precise, no function overhead */
#include <string.h>        /* memcmp, memcpy */

/* ── Constructor ────────────────────────────────────────────────────────── */
OneWireTag::OneWireTag(uint8_t pin)
    : _pin(pin),
      _portBitmask(digitalPinToBitMask(pin)),
      _ow(pin)
{}

/* ── Read ───────────────────────────────────────────────────────────────── */

OWResult OneWireTag::readRaw(uint8_t* romCode)
{
    if (!_reset()) return OWResult::NO_PRESENCE;

    /*
     * READ ROM command sent via standard OneWire write slots.
     * Write timing (60 µs LOW for '0', 10 µs LOW for '1') has ample margin
     * at 10 MHz; only the read sample point is timing-critical here.
     */
    _ow.write(0x33u);

    /*
     * Read 8 bytes using _readByte() / _readBit() instead of _ow.read().
     * See _readBit() for the full explanation of why _ow.read() fails at
     * 10 MHz (sample lands at ~16–17 µs, past the DS1990's 15 µs tRDV).
     */
    for (uint8_t i = 0; i < OW_ROM_BYTES; ++i) {
        romCode[i] = _readByte();
    }

    if (OneWire::crc8(romCode, 7) != romCode[7]) return OWResult::CRC_ERROR;
    return OWResult::OK;
}

OWResult OneWireTag::read(uint8_t* romCode)
{
    const OWResult r = readRaw(romCode);
    if (r != OWResult::OK) return r;
    if (!isCompatible(romCode)) return OWResult::WRONG_FAMILY;
    return OWResult::OK;
}

OWResult OneWireTag::scanNext(uint8_t* romCode)
{
    if (!_ow.search(romCode)) return OWResult::NO_PRESENCE;
    if (OneWire::crc8(romCode, 7) != romCode[7]) return OWResult::CRC_ERROR;
    if (!isCompatible(romCode)) return OWResult::WRONG_FAMILY;
    return OWResult::OK;
}

void OneWireTag::resetSearch()
{
    _ow.reset_search();
    delay(1);  /* bus settle */
}

/* ── Write ──────────────────────────────────────────────────────────────── */

OWResult OneWireTag::write(const uint8_t* romCode, bool useAltCmd)
{
    /* Step 1 — verify a tag is present before programming */
    if (!_reset()) return OWResult::NO_PRESENCE;

    /* Step 2 — send write-enable command using standard 60 µs OneWire slots */
    _ow.write(useAltCmd ? RW_CMD_WRITE_ALT : RW_CMD_WRITE);

    /* Step 3 — release bus; chip enters write mode */
    delay(RW_ENTER_MS);

    /* Step 4 — write 64 bits, LSB of byte 0 first */
    for (uint8_t byte = 0; byte < OW_ROM_BYTES; ++byte) {
        for (uint8_t bit = 0; bit < 8; ++bit) {
            _writeBit((romCode[byte] >> bit) & 0x01u);
        }
    }

    /* Step 5 — reset to exit write mode */
    _ow.reset();

    /* Step 6 — EEPROM burn settle */
    delay(RW_SETTLE_MS);

    return OWResult::OK;
}

/* ── Verify ─────────────────────────────────────────────────────────────── */

OWResult OneWireTag::verify(const uint8_t* expected)
{
    uint8_t actual[OW_ROM_BYTES];
    const OWResult r = readRaw(actual);
    if (r != OWResult::OK) return r;
    if (memcmp(actual, expected, OW_ROM_BYTES) != 0) return OWResult::VERIFY_FAIL;
    return OWResult::OK;
}

/* ── Program ────────────────────────────────────────────────────────────── */

OWResult OneWireTag::program(uint8_t* romCode)
{
    /* Auto-fill CRC when caller leaves byte 7 as zero */
    if (romCode[7] == 0x00u) romCode[7] = crc8(romCode, 7);

    /* Sanity-check the CRC before attempting to burn it */
    if (crc8(romCode, 7) != romCode[7]) return OWResult::CRC_ERROR;

    const OWResult wr = write(romCode);
    if (wr != OWResult::OK) return wr;

    return verify(romCode);
}

/* ── Static utilities ───────────────────────────────────────────────────── */

uint8_t OneWireTag::crc8(const uint8_t* data, uint8_t len)
{
    return OneWire::crc8(data, len);
}

bool OneWireTag::isCompatible(const uint8_t* romCode)
{
    return (romCode[0] == OW_FAMILY_DS1990);
}

void OneWireTag::buildRomCode(const uint8_t* serial6, uint8_t* romCode)
{
    romCode[0] = OW_FAMILY_DS1990;
    memcpy(&romCode[1], serial6, 6);
    romCode[7] = crc8(romCode, 7);
}

void OneWireTag::printRomCode(const uint8_t* romCode)
{
    for (uint8_t i = 0; i < OW_ROM_BYTES; ++i) {
        if (romCode[i] < 0x10u) Serial.print('0');
        Serial.print(romCode[i], HEX);
        if (i < OW_ROM_BYTES - 1u) Serial.print(':');
    }
    Serial.println();
}

void OneWireTag::printResult(OWResult r)
{
    switch (r) {
        case OWResult::OK:           Serial.println(F("OK"));           break;
        case OWResult::NO_PRESENCE:  Serial.println(F("NO_PRESENCE"));  break;
        case OWResult::CRC_ERROR:    Serial.println(F("CRC_ERROR"));    break;
        case OWResult::WRONG_FAMILY: Serial.println(F("WRONG_FAMILY")); break;
        case OWResult::VERIFY_FAIL:  Serial.println(F("VERIFY_FAIL"));  break;
        case OWResult::BUS_ERROR:    Serial.println(F("BUS_ERROR"));    break;
        default:                     Serial.println(F("UNKNOWN"));      break;
    }
}

/* ── Private ────────────────────────────────────────────────────────────── */

bool OneWireTag::_reset()
{
    /*
     * First attempt: use the standard OneWire library reset.
     * This covers the normal case and is correctly timed for tinyAVR 2-series
     * with OneWire v2.3.7+ when F_CPU matches the IDE clock setting.
     */
    if (_ow.reset()) return true;

    /*
     * Second attempt: robust manual reset with a widened presence window.
     *
     * WHY THIS IS NEEDED:
     * The library samples presence at exactly 70 µs after releasing the bus.
     * If delayMicroseconds(70) runs even slightly long (e.g. the chip clock
     * is calibrated slightly below nominal, or there is minor loop overhead
     * variation), the 132 µs presence pulse may have ended by the time the
     * sample is taken → reset() returns 0 → false NO_PRESENCE result.
     *
     * This fallback issues its own 520 µs reset LOW (10 % guard above the
     * 480 µs minimum so the tag always sees a valid reset even with a slow
     * clock), then polls the bus every 10 µs for up to 150 µs after release.
     * Any LOW reading within that window counts as valid presence.
     *
     * The 150 µs window covers presence pulses from 10 µs to 150 µs after
     * the bus is released, accommodating both short and long presence delays.
     *
     * Interrupts are disabled only during the critical sections (LOW drive
     * and sampling), matching the OneWire library's own approach.
     */
    noInterrupts();
    pinMode(_pin, OUTPUT);
    digitalWrite(_pin, LOW);
    interrupts();

    delayMicroseconds(520u);          /* reset pulse: 520 µs > 480 µs minimum */

    noInterrupts();
    pinMode(_pin, INPUT);             /* release bus; pullup restores HIGH */
    interrupts();

    /* Poll for presence over a 150 µs window, sampling every 10 µs */
    bool present = false;
    for (uint8_t i = 0; i < 15u; ++i) {
        delayMicroseconds(10u);
        if (digitalRead(_pin) == LOW) {
            present = true;
            break;
        }
    }

    /*
     * Complete the standard 1-Wire reset slot (480 µs LOW + 480 µs recovery).
     * We spent ~520 µs on the LOW + up to 150 µs sampling = up to 670 µs.
     * A standard reset slot is 960 µs total; wait for the remainder.
     */
    delayMicroseconds(300u);

    return present;
}

uint8_t OneWireTag::_readBit()
{
    /*
     * Tightly-timed 1-Wire read slot.
     *
     * ROOT CAUSE OF 0xFF BUG:
     * ────────────────────────
     * DS1990 tRDV (Read Data Valid) = 15 µs max.  This is the deadline from
     * the slot-start falling edge by which the master MUST sample the bus.
     * After tRDV the tag releases its '0'-bit pull-down and the bus returns
     * to pullup HIGH.  Sampling late reads '1' for every bit → 0xFF.
     *
     * OneWire::read_bit() at 10 MHz:
     *   DIRECT_WRITE_LOW + DIRECT_MODE_OUTPUT   ~2 cycles
     *   delayMicroseconds(3) call + loop         ~42 cycles  = 4.2 µs
     *   DIRECT_MODE_INPUT                        ~1 cycle
     *   delayMicroseconds(10) call + loop        ~112 cycles = 11.2 µs
     *   DIRECT_READ                              ~1 cycle
     *   ─────────────────────────────────────────────────────
     *   Total                                    ~158 cycles = 15.8 µs  ← LATE
     *
     * This implementation uses single-cycle VPORTA register writes (CBI/SBI
     * instructions — no function-call overhead) and _delay_us() compile-time
     * constants, achieving a sample at ≈ 11 µs — well within tRDV = 15 µs.
     *
     *   VPORTA.DIR |= bm   (SBI)   1 cycle
     *   VPORTA.OUT &= ~bm  (CBI)   1 cycle   ← t=0, slot-start falling edge
     *   _delay_us(3)               30 cycles  = 3.0 µs
     *   VPORTA.DIR &= ~bm  (CBI)   1 cycle    release bus
     *   _delay_us(7)               70 cycles  = 7.0 µs
     *   VPORTA.IN read             1 cycle   ← sample at ~11.1 µs  ✓
     *   ─────────────────────────────────────────────────────
     *   Total to sample            104 cycles = 10.4 µs + ~0.7 µs overhead
     *                                         ≈ 11.1 µs  (< 15 µs tRDV) ✓
     *
     * VPORTA is hardcoded because PA4 is on Port A of the ATtiny3224.
     * _portBitmask is the precomputed digitalPinToBitMask(_pin) value.
     *
     * SEARCH ROM note:  _ow.search() uses _ow.read_bit() internally and has
     * the same late-sample issue at 10 MHz.  Avoid scanNext() until a patched
     * OneWire library is available; use read() (single-device READ ROM) instead.
     */
    uint8_t r;
    const uint8_t bm = _portBitmask;

    noInterrupts();
    VPORTA.DIR |=  bm;          /* OUTPUT                              (SBI) */
    VPORTA.OUT &= ~bm;          /* LOW — slot-start falling edge       (CBI) */
    _delay_us(3);               /* 3 µs start pulse (spec: 1–15 µs)         */
    VPORTA.DIR &= ~bm;          /* INPUT — release, tag may now drive  (CBI) */
    _delay_us(7);               /* pre-sample wait                          */
    r = (VPORTA.IN & bm) ? 1u : 0u;   /* sample at ≈ 11 µs               */
    interrupts();

    _delay_us(56);              /* complete slot: 3+7+56 = 66 µs total      */
    return r;
}

uint8_t OneWireTag::_readByte()
{
    uint8_t byte = 0;
    for (uint8_t bit = 0; bit < 8u; ++bit) {
        byte |= (_readBit() << bit);   /* LSB first, matching 1-Wire convention */
    }
    return byte;
}

void OneWireTag::_writeBit(uint8_t bit)
{
    /*
     * RW1990 extended-pulse write slot.
     *
     * The OneWire library write slots are 60 µs; RW1990 programming requires
     * 5–10 ms pulses.  The library is bypassed here; the pin is driven
     * directly.
     *
     * OUTPUT + LOW  →  pull bus to GND (programming current into tag)
     * INPUT         →  release bus (4.7 kΩ pullup restores HIGH)
     *
     * Interrupts remain ENABLED during delay() so:
     *  • TCB1 (or TCB0) millis() tick continues accumulating normally.
     *  • TCA0 hardware PWM continues running; the LED output is unaffected.
     *
     * The 5–10 ms pulse has no timing sensitivity comparable to 1-Wire data
     * slots, so interrupt latency of a few microseconds is inconsequential.
     */
    pinMode(_pin, OUTPUT);
    digitalWrite(_pin, LOW);
    delay(bit ? RW_PULSE_ONE_MS : RW_PULSE_ZERO_MS);

    pinMode(_pin, INPUT);             /* release — pullup restores idle HIGH */
    delay(RW_RELEASE_MS);
}
