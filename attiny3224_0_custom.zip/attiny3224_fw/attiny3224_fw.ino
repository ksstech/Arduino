/**
 * attiny3224_fw.ino  —  ATtiny3224 firmware  |  megaTinyCore 2.6.11
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  WHY Arduino.h AND NOT megaTinyCore.h
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  megaTinyCore is a BOARD SUPPORT PACKAGE (BSP), not a library.  A BSP
 *  provides the Arduino framework for a family of chips; it has no public
 *  header of its own.  The correct entry point is always:
 *
 *      #include <Arduino.h>
 *
 *  When the ATtiny3224 target is selected in the IDE, the compiler resolves
 *  that include to:
 *
 *      {megaTinyCore}/cores/megatinycore/Arduino.h
 *
 *  That file pulls in every megaTinyCore-specific extension automatically:
 *  PIN_PAn / PIN_PBn macros, MEGATINYCORE_VERSION, tinyAVR 2-series register
 *  definitions (VPORT, TCA, TCB, …), analogWrite() split-mode PWM, etc.
 *
 *  There is no "megaTinyCore.h" to include — it does not exist.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  MANDATORY IDE SETTINGS  (Tools menu)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  Board                : ATtiny3224 / 3214 / 3204 (megaTinyCore)
 *  Chip                 : ATtiny3224
 *  Clock Source         : 10 MHz internal             ← REQUIRED at 3.3 V; see below
 *  millis()/micros()    : TCB0 or TCB1 (any TCB)      ← must NOT be TCA0
 *  Programmer           : SerialUPDI (HV) via PA0
 *
 *  CLOCK SPEED IS COUPLED TO VCC — tinyAVR 2-series datasheet DS40002315:
 *    0– 5 MHz  at 1.8–5.5 V  (Speed Grade 1)
 *    0–10 MHz  at 2.7–5.5 V  (Speed Grade 2)  ← this board at 3.3 V
 *    0–20 MHz  at 4.5–5.5 V  (Speed Grade 3)
 *
 *  At VCC = 3.3 V, 20 MHz is outside the guaranteed operating envelope.
 *  The chip may appear to run but delayMicroseconds() — a busy-loop scaled
 *  by F_CPU — can mis-time under marginal conditions.  For OneWire this
 *  directly stretches the 70 µs presence-sample delay past the end of the
 *  132 µs presence pulse, causing missed detections and CRC failures.
 *  Select 10 MHz; all timing constants (delayMicroseconds, millis, the
 *  OneWire library) scale automatically via F_CPU — no code changes needed.
 *  PWM frequency becomes: 10 MHz ÷ (64 × 256) ≈ 610 Hz — still adequate.
 *
 *  millis() timer: megaTinyCore 2.6.x defaults to TCB1 on ATtiny3224.
 *  TCB0 also works.  Either is fine.  The only forbidden choice is TCA0:
 *  that prevents split-mode PWM and corrupts OneWire inter-slot timing.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  TIMER ALLOCATION  (ATtiny3224, tinyAVR 2-series)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  TCB1  millis()/micros() — 1 ms periodic interrupt.  Configured by core.
 *        megaTinyCore 2.6.x default on ATtiny3224.  TCB0 also works if
 *        changed in the IDE; either choice leaves TCA0 free for PWM.
 *        TCB1 WO default is PA3; it is OUTPUT-COMPARE-disabled in periodic
 *        mode, so PA3 remains usable as LED GPIO / PWM output.
 *
 *  TCB0  Free.  Reserve for future input-capture, precise pulse timing, or
 *        hardware PWM.  Default WO on PA2.
 *
 *  TCA0  Split mode, fully dedicated to PWM via analogWrite().
 *        10 MHz ÷ (prescaler 64 × 256 counts) ≈ 610 Hz PWM frequency.
 *        Split-mode WO routing for 14-pin package (PB4/PB5 absent):
 *          PORTMUX.TCAROUTEA selects PA-group for WO3–WO5
 *          WO5 → PA5  (HCMP2 / LCMP2, channel 1 in this firmware — LED)
 *          WO3 → PA3  (HCMP0 / LCMP0, channel 0 if a second LED is fitted)
 *          WO4 → PA4  — NOT enabled (PA4 is the 1-Wire bus; enabling WO4
 *                        here would fight the 1-Wire driver).
 *                        Do NOT call analogWrite(PIN_PA4, …).
 *
 *  RTC   Unused.  Reserved for deep-sleep wakeup via 32 kHz internal osc.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  PIN ASSIGNMENT
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  PA0  UPDI      AdaFruit HV Friend SerialUPDI.  Permanently UPDI on
 *                 tinyAVR 2-series; never use as GPIO.
 *
 *  PA2  RELAY     Active-HIGH digital output.  TCA0 WO2 is also on PA2;
 *                 never call analogWrite(PIN_PA2, …).
 *
 *  PA3  LED_AUX   Optional second status LED (hardware PWM WO3 → PA3).
 *                 If not fitted, leave configure(1, …) absent or call stop(1).
 *
 *  PA4  1-WIRE    DS1990 / RW1990 bus.  4.7 kΩ pullup to VCC required.
 *
 *  PA5  LED       Primary status LED, hardware PWM WO5 → PA5.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *  REQUIRED LIBRARY  (install via Library Manager)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  OneWire  by Paul Stoffregen  ≥ v2.3.7
 *  https://github.com/PaulStoffregen/OneWire
 */

#include <Arduino.h>
#include "StatusLED.h"
#include "OneWireTag.h"

/* ── Pin definitions ────────────────────────────────────────────────────── */
static constexpr uint8_t PIN_LED_PRIMARY = PIN_PA5;
static constexpr uint8_t PIN_LED_AUX     = PIN_PA3;   /* second channel; WO3 */
static constexpr uint8_t PIN_ONEWIRE     = PIN_PA4;
static constexpr uint8_t PIN_RELAY       = PIN_PA2;

/* ── LED: 2-channel instance ────────────────────────────────────────────── */
/*
 * Pin array is the single source of pin assignment for all LED channels.
 * Channel 0 = PA5 (primary status LED)
 * Channel 1 = PA3 (auxiliary LED — omit configure() call if not fitted)
 *
 * The array length N_CH is deduced by the template from the initialiser;
 * adding a third element automatically generates a 3-channel StatusLED.
 */
static const uint8_t kLEDPins[] = { PIN_LED_PRIMARY, PIN_LED_AUX };
StatusLED<2> leds(kLEDPins);

/* ── 1-Wire ─────────────────────────────────────────────────────────────── */
OneWireTag owTag(PIN_ONEWIRE);

/* ── Relay helpers ──────────────────────────────────────────────────────── */
inline void relayOn()  { digitalWrite(PIN_RELAY, HIGH); }
inline void relayOff() { digitalWrite(PIN_RELAY, LOW);  }

/* ══════════════════════════════════════════════════════════════════════════
   Forward declarations
   ══════════════════════════════════════════════════════════════════════════ */
void demoOneWireScan();
void demoRelay();

/* ══════════════════════════════════════════════════════════════════════════
   setup()
   ══════════════════════════════════════════════════════════════════════════ */
void setup()
{
    Serial.begin(115200);
    while (!Serial && millis() < 2000) {}
    Serial.println(F("ATtiny3224 init"));
    Serial.print(F("F_CPU = ")); Serial.println(F_CPU);

    /* Relay — de-energise on power-up */
    pinMode(PIN_RELAY, OUTPUT);
    relayOff();

    /*
     * LED channel 0 (PA5) — slow breathing heartbeat, infinite.
     *
     * API: configure(channel, repeats, fadeInSec, onSec, fadeOutSec, offSec)
     *
     *  channel    : 0 = PA5, 1 = PA3
     *  repeats    : LED_STOP (0), LED_INFINITE (65535), or 1–65534
     *  *Sec       : 0 = skip stage; 1–65535 = duration in whole seconds
     */
    leds.configure(0, LED_INFINITE, 2, 1, 2, 1);

    /*
     * LED channel 1 (PA3) — three blinks then idle.
     * Remove or comment out if PA3 is not connected to an LED.
     */
    leds.configure(1, 3, 0, 1, 0, 1);

    Serial.println(F("Setup complete"));
}

/* ══════════════════════════════════════════════════════════════════════════
   loop()
   ══════════════════════════════════════════════════════════════════════════ */
void loop()
{
    /* MUST be first: drive all LED state machines */
    leds.update();

    /* 1-Wire tag scan */
    demoOneWireScan();

    /* Relay demo (uncomment to enable) */
    // demoRelay();
}

/* ══════════════════════════════════════════════════════════════════════════
   1-Wire diagnostic scan
   ══════════════════════════════════════════════════════════════════════════ */
void demoOneWireScan()
{
    static uint32_t lastMs = 0;
    if (millis() - lastMs < 500UL) return;
    lastMs = millis();

    uint8_t rom[OW_ROM_BYTES];

    /*
     * readRaw() returns raw bytes regardless of CRC or family code.
     * Use during bring-up to see exactly what the tag is sending.
     * Switch to read() once the bus is confirmed working.
     */
    const OWResult result = owTag.readRaw(rom);

    Serial.print(F("OW: "));
    OneWireTag::printResult(result);

    if (result == OWResult::OK || result == OWResult::WRONG_FAMILY) {
        /* Print ROM even on WRONG_FAMILY so you can inspect the family byte */
        Serial.print(F("  ROM: "));
        OneWireTag::printRomCode(rom);

        Serial.print(F("  Family: 0x"));
        if (rom[0] < 0x10u) Serial.print('0');
        Serial.println(rom[0], HEX);

        Serial.print(F("  CRC check: "));
        Serial.println(OneWire::crc8(rom, 7) == rom[7] ? F("PASS") : F("FAIL"));
    }

    if (result == OWResult::CRC_ERROR) {
        /* Print raw bytes so you can spot bit-flip patterns */
        Serial.print(F("  Raw bytes: "));
        OneWireTag::printRomCode(rom);
        Serial.print(F("  Expected CRC: 0x"));
        const uint8_t expectedCRC = OneWire::crc8(rom, 7);
        if (expectedCRC < 0x10u) Serial.print('0');
        Serial.println(expectedCRC, HEX);
    }

    /* ── Example: write new ID to an RW1990 tag ──────────────────────── */
    /*
    if (result == OWResult::OK) {
        uint8_t newRom[OW_ROM_BYTES] = { 0 };
        const uint8_t serial[6] = { 0x01, 0x23, 0x45, 0x67, 0x89, 0xAB };
        OneWireTag::buildRomCode(serial, newRom);

        Serial.print(F("Programming: "));
        OneWireTag::printRomCode(newRom);

        const OWResult pr = owTag.program(newRom);
        Serial.print(F("Program result: "));
        OneWireTag::printResult(pr);
    }
    */
}

/* ══════════════════════════════════════════════════════════════════════════
   LED preset helpers  —  call from anywhere to change LED behaviour
   ══════════════════════════════════════════════════════════════════════════ */

/** Channel 0: slow breath, infinite */
void ledHeartbeat()   { leds.configure(0, LED_INFINITE, 2, 1, 2, 1); }

/** Channel 0: three fast blinks (1 s on, 1 s off) */
void ledError()       { leds.configure(0, 3, 0, 1, 0, 1); }

/** Channel 0: single long pulse */
void ledAck()         { leds.configure(0, 1, 1, 2, 1, 0); }

/** Channel 0: off */
void ledOff()         { leds.configure(0, LED_STOP, 0, 0, 0, 0); }

/** All channels: off */
void ledsAllOff()     { leds.stopAll(); }

/* ══════════════════════════════════════════════════════════════════════════
   Relay demonstration
   ══════════════════════════════════════════════════════════════════════════ */
void demoRelay()
{
    static uint32_t lastMs = 0;
    static bool     state  = false;

    if (millis() - lastMs < 5000UL) return;
    lastMs = millis();
    state  = !state;
    state ? relayOn() : relayOff();

    Serial.print(F("Relay: "));
    Serial.println(state ? F("ON") : F("OFF"));
}
