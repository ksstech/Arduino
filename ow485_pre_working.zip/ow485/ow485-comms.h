// ow485-comms.h

// Global variables
uint32_t RunTime;
uint8_t UPhr, UPmin, UPsec, DevID;
uint16_t UPdays, UPmsec;

// External variables
extern int __heap_start, *__brkval;

void updateUpTime(void) {
  uint32_t T = RunTime = millis();
  UPmsec = T % 1000UL;
  T /= 1000;
  UPsec = T % 60UL;
  T /= 60;
  UPmin = T % 60UL;
  T /= 60;
  UPhr = T % 24UL;
  T /= 24;
  UPdays = T;
}

void rs485SetMode(bool transmit) {
  if (transmit) {
    digitalWrite(pin485REDE, HIGH);
  } else {
    Serial.flush(); 
    digitalWrite(pin485REDE, LOW);
  }
}

char mapIndexToChar(int8_t Idx) { return ((Idx % 8) == 0) ? ' ' : ((Idx % 4) == 0) ? '|' : ((Idx % 2) == 0) ? '-' : ':'; }

void serialPrintArray(HardwareSerial * SerialX, const char * Heading, uint8_t (*Func)(int), int16_t Len) {
  SerialX->print(Heading);
  for (int16_t Idx = 0; Idx < Len; ++Idx) {
    if ((Idx & 0x0F) == 0)
      SerialX->printf("\n0x%02x: ", Idx);
    SerialX->printf("%02X%c", Func(Idx), mapIndexToChar(Idx));
  }
  SerialX->println();
}

auto readEEPROM  = [](int addr) -> uint8_t { return EEPROM.read(addr);  };
auto readUSERSIG = [](int addr) -> uint8_t { return USERSIG.read(addr); };

void serialPrint(const char * pString) {
    rs485SetMode(1);
    Serial.println(pString);
    rs485SetMode(0);
}

void serialPrintOptions(const char * pString, int Options) {
  HardwareSerial * SerialX;
  if (Options & PO_CHANNEL) {
    SerialX = &Serial1;
  } else {
    rs485SetMode(1);
    SerialX = &Serial0;
  }
  if (Options & PO_ADDR)            SerialX->printf("%lu:%02x ", millis(), DevID);
  if (Options & PO_UPTIME) {
    updateUpTime();
    SerialX->printf("(%lu) %ud %02uh%02um%02u.%03u\n", RunTime, UPdays, UPhr, UPmin, UPsec, UPmsec);
  }
  if (Options & PO_ONEWIRE) {
    for(int8_t i = 0; i < 8; ++i)   SerialX->printf("%02x%c ", owCode[i], (i == 0 || i == 6) ? ':' : (i == 7) ? ' ' : 0);
    SerialX->printf("C0=%lu C1=%lu C2=%lu (%d) %s\n", countRD0, countRD1, countRD2, owStatus, iButtonStatusMessage());
  }
  if (Options & PO_RLY_LED)         SerialX->printf("Relay=%d | LED %u / %u -> %u -> %u -> %u\n",
                                        RLYstat, pwmInfo.para[0], pwmInfo.para[1], pwmInfo.para[2], pwmInfo.para[3], pwmInfo.para[4]);
  if (Options & PO_FIRMWARE)        SerialX->print(DEV_HW_INFO " / " DEV_FW_INFO " / PWM=" toSTR(USE_PWM_DRIVER) "\n");
  if (Options & PO_CMDBUF)          SerialX->printf("'%s' L=%d\n", CmdBuf.c_str(), CmdBuf.length());
  if (Options & PO_SYSSTAT) {
    int Mem = (int)(&Mem) - (__brkval == 0 ? (int)&__heap_start : (int)__brkval);
    SerialX->printf("Vcc=%umV  Temp=%d°C  Free=%dB\n", readSupplyVoltage(), readTemp() - 273, Mem);
  }
  if (Options & PO_EEPROM)          serialPrintArray(SerialX, "EEPROM", readEEPROM, 256);
  if (Options & PO_USERROW)         serialPrintArray(SerialX, "USERROW", readUSERSIG, 32);
  if (pString)                      SerialX->println(pString); // if NULL pointer then also no newline...
  if ((Options & PO_CHANNEL) == 0) {
    rs485SetMode(0);
  }
}

/*
 * Host buffer consume support
 */
uint8_t convertUpperToHex(char c) {
  if (c >= '0' && c <= '9')
    return c - '0';
  if (c >= 'A' && c <= 'F')
    return c - 'A' + 10;
  return 0xFF;
}

char hostConsumeChar(void) {
  if (CmdBuf.length() > 0) {
    char cChr = CmdBuf.charAt(0);
    CmdBuf.remove(0, sizeof(char));
    return cChr;
  }
  return -1;
}

char hostConsumeHexChar(void) {
  return convertUpperToHex(hostConsumeChar());
}

long int hostConsumeHexValue(int8_t Num) {
  long int iVal = 0;
  int8_t Idx = 0;
  do {
    char cChr = hostConsumeChar();                  // get next char
    if (cChr == ',' || cChr == -1)                  // seperator or terminator reached?
      break;                                        // stop parsing
    uint8_t u8Val = convertUpperToHex(cChr);        // convert char to hex value equivalent
    if (u8Val == 0xFF)                              // Invalid / non-hex char
      return -1;                                    // immediate error
    iVal <<= 4;
    iVal += u8Val;
  } while (++Idx < Num);
  if (Idx == Num) {                                 // requested # of chars consumed...
    if (CmdBuf.charAt(0) == ',')                    // seperator next char?
      hostConsumeChar();                            // waste it.....
  }
  return (Idx == 0 || Idx > Num) ? -1L : iVal;
}

uint8_t hostConsumeString(char * Buf, uint8_t u8S) {
  CmdBuf.toCharArray(Buf, u8S);
  if (CmdBuf.charAt(u8S - 1) != ',')
    --u8S;
  CmdBuf.remove(0, u8S);
  return u8S;
}

bool hostReadCmd(void) {
  if (Serial.available() > 0) {
    char c = Serial.read();
    if (c == '\n' || c == '\r') {
      if (CmdBuf.length() > 0) {
        CmdBuf.toUpperCase();
        return true; 
      }
      return false;
    }
    CmdBuf += c;
  }
  return false;
}
