/*
 * RS485 to OneWire - Copyright (c) 2026 Andre M. Maree / KSS Technologies (Pty) Ltd.
 * 
 * https://onlinedocs.microchip.com/oxy/GUID-ACE76F82-8072-410B-AFA7-16B2BF7B4CBA-en-US-8/index.html

 * https://www.electronics-lab.com/wp-content/uploads/2022/05/ATtiny-3224-pinout.jpg
 * 
 * https://www.electronics-lab.com/attiny-development-boards-are-compatible-with-arduino-ide/

 * Some thoughts:
 *  Limit number of slaves on bus
 *  Limit valid address range of slave devices
 *  Add command to provide config parameters to the client
 *  Allow OW GPIO reads to be interval scheduled and automatically reported to host 
 *  Open command scope to specify a GPOut/Actuator bitmap (multiple devices) to switch more than one on or off
 *   0 1 2 3 4 5 6 7
 *   1 x 1 x x 1 0 x
 *  Similarly a command to specify a GPIn / binary sensor mask to read more than 1 device, same format as the actuator command
 *  Broadcast address 0xFF
 *  Start of open window for slaves to respond if needed
 */

// BUILD definitions required by includes below...
#define DEBUG_LEVEL               1         // 0=disabled, 1=errors, 2=???, 3=verbose
#define USE_UPDI_PRINT            0
#define USE_IBUTTON_TAG           0
#define USE_PWM_DRIVER            2

#include <megaTinyCore.h>
#include <EEPROM.h>
#include <USERSIG.h>
#include <OneWire.h>
#if (USE_IBUTTON_TAG == 1)
  #include <iButtonTag.h>
#endif
#include <ow485-platform.h>                 // hardware platform related, not application specific

#include "ow485-app.h"                      // application specific
#include "ow485-pwm.h"
#if (USE_IBUTTON_TAG == 1)
  #include "ow485-ibutton.h"
#else
  #include "ow485-onewire.h"
#endif
#include "ow485-comms.h"

// UART Buffer sizes
#undef SERIAL_TX_BUFFER_SIZE
#undef SERIAL_RX_BUFFER_SIZE
#define SERIAL_TX_BUFFER_SIZE     32
#define SERIAL_RX_BUFFER_SIZE     32

const char helpText[] =
  "All commands should be sent as a comma separated (CSV) ASCII string with NO spaces and ONLY an NL terminator\n" \
  "Format of a command is XX,??[,xx..zz] where\n" \
  " XX  2 byte hexadecimal address, possibly limited in range\n" \
  " ??  2 byte alphanumeric command being one of the following\n" \
  "     AP  Actuator command/config\n"
  "         rr[,fi[,on[,fo[,of]]]]\n"
  "     CA  Config Address, store hex value as new device ID\n" \
  "     CG  Config GPIO as in/out based on additional parameters\n" \
  "     SA  System Address\n" \
  "         YY being the requested device address in hex\n" \
  "     SI  System Info request\n" \
  "         { FW ver, MCU clock, MCU ID, Silicon Revision }\n" \
  "     SR  System Reboot\n" \
  "     OR  Read IButton data\n" \
  "     OW  Write new data on Ibutton device\n" \
  "         AB9876543210 being the address in hex to be written to the tag\n" \
  "     RT  Relay On\n" \
  "     RF  Relay Off\n" \
  "     LT  LED On\n" \
  "     LF  LED Off\n" \
  " 10,rT  -or-  11,Ca,27  -or-  1D,or  -or- 18,OW,AB9876543210  -or- 15,ap,ffff,1000,2000,3000,4444\n";

void actuatePWM(void) {
//  memset((void *)pwmInfo.para, 0, sizeof(pwmInfo.para));            // ensure all default to 0
  int8_t Idx = 0;
  long int iVal;
  do {
    if (DEBUG_LEVEL > 2) serialPrintOptions(NULL, PO_CMDBUF);
    iVal = hostConsumeHexValue(4);         // max 4 hex digits
    if (iVal == -1)                        // error ?
      break;                               // yes, break out
    pwmInfo.para[Idx++] = (uint16_t) iVal;         // no, store value
  } while (Idx < enNUM);
  #if (DEBUG_LEVEL > 0)
    {
      char Message[64];
      snprintf(Message,sizeof(Message), "iVal=%lx Idx=%d 0=%x 1=%x 2=%x 3=%x 4=%x", iVal, Idx,
          pwmInfo.para[0], pwmInfo.para[1], pwmInfo.para[2], pwmInfo.para[3], pwmInfo.para[4]);  
      serialPrintOptions(Message, PO_ADDR);
    }
  #endif
  if (Idx == 0)
    return;
  startLedSequence();
}

void SetRLY(bool stat) {
  digitalWrite(pinRelay, RLYstat = stat);
  if (DEBUG_LEVEL > 2) serialPrintOptions(NULL, PO_ADDR | PO_RLY_LED);
}

void system_address(void) {
  long int iVal = hostConsumeHexValue(2);
  if (iVal == -1) {
    if (DEBUG_LEVEL > 2) serialPrintOptions("Invalid HEX", PO_ADDR);
    return;
  }
  USERSIG.update(UR_IDX_DEVID, DevID = owAddr = (uint8_t) iVal);
  USERSIG.flush();
}

void system_reset(void) {
  serialPrintOptions("Rebooting", PO_ADDR | PO_CHANNEL);
  _PROTECTED_WRITE(WDT.CTRLA, WDT_PERIOD_8CLK_gc); //enable the WDT, minimum timeout
  while (1); // spin until reset
}

void setup(void) {
  CmdBuf.reserve(32);                   // 2(addr) + 1(sep) + 2(cmd) + 12(code) + 1(NUL)
  DevID = USERSIG.read(UR_IDX_DEVID);   // Setup Device ID to be used
  if (DevID == 0xFF)                    // If no valid address set (yet)
    DevID = 0x10;                       // use default

  // Initialise RS486 serial comms
  Serial.begin(19200);                  // RS485 channel
  Serial.flush();
  pinMode(pin485REDE, OUTPUT);          // Init RS485 REDE

  #if (USE_UPDI_PRINT == 1)    // configure UPDI for debug logging output
  Serial1.pins(pinUPDI, PIN_NONE);
  Serial1.pins(pinUPDI, SERIAL_TX_ONLY);
  Serial1.begin(19200);                 // UPDI channel
  Serial1.flush();
  #endif

  // Initialise Relay GPIO
  pinMode(pinRelay, OUTPUT);
  digitalWrite(pinRelay, LOW);

  // initialise LED pin for PWM
  setup_pwm();

  if (DEBUG_LEVEL > 0) serialPrintOptions("Started", PO_ADDR);
}

void loop() {
  if (hostReadCmd()) {
    if (DEBUG_LEVEL > 2) serialPrintOptions("", PO_CMDBUF);
    long int iVal = hostConsumeHexValue(2);     // read 1 or 2 hex address bytes
    if (iVal != -1L) {                          // Value hex value found
      owAddr = iVal;
      if (owAddr == DevID) {
        // save 2 bytes as actual command, remove from buffer [incl comma]
        char Command[3];
        iVal = hostConsumeString(Command, sizeof(Command));
        if (DEBUG_LEVEL > 2) serialPrintOptions(Command, PO_CMDBUF);
        if (strncmp(Command, "OR", 2) == 0)       iButtonRead();
        else if (strncmp(Command, "OW", 2) == 0)  iButtonWrite();
        else if (strncmp(Command, "RT", 2) == 0)  SetRLY(1);
        else if (strncmp(Command, "RF", 2) == 0)  SetRLY(0);
        else if (strncmp(Command, "LT", 2) == 0)  SetLED(1);
        else if (strncmp(Command, "LF", 2) == 0)  SetLED(0);
        else if (strncmp(Command, "AP", 2) == 0)  actuatePWM();
        else if (strncmp(Command, "SA", 2) == 0)  system_address();
        else if (strncmp(Command, "SI", 2) == 0)  serialPrintOptions("", PO_ADDR|PO_FIRMWARE|PO_UPTIME|PO_SYSSTAT|PO_RLY_LED|PO_ONEWIRE);
        else if (strncmp(Command, "SR", 2) == 0)  system_reset();
        else                                      serialPrintOptions(helpText, PO_ADDR/* | PO_CHANNEL*/);
      } else {
        if (DEBUG_LEVEL > 2) serialPrintOptions("Unknown Address", PO_ADDR);
      }
    } else {
      if (DEBUG_LEVEL > 2) serialPrintOptions("Invalid packet", PO_ADDR);
    }
    // Reset ALL command buffer values
    CmdBuf = "";
  } else if (triggerIButtonRead) {
    SetLED(1);
    triggerIButtonRead = false;
    ++countRD0;
    owStatus = 0;
    iButtonRead();
    SetLED(0);
    if (owStatus == 1) {
      loadLedSequence(10, 0, 500, 0, 500);
      ++countRD1;
    }
  } else {
      ++countRD2;
    // If no request received and not scheduled to read an iButton trigger...
    // do whatever else requires attention.
  }
}

// { char Message[32]; snprintf(Message, sizeof(Message), "iVal=x%04lX", iVal); serialPrintOptions(Message, PO_CMDBUF); }
