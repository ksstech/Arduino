// ow485-pwm.h

#ifndef MILLIS_USE_TIMERB1 
  #ifndef MILLIS_USE_TIMERRTC
    #error "Please go to Tools -> Timer for Millis and select TCB1 or RTC so TCB0 is free!"
  #endif
#endif

#if (F_CPU != 10000000UL)
  #warning "Arduino IDE Clock is not set to 10 MHz! Timings may be skewed."
#endif

// ####################################### Enumerations ############################################

typedef enum { STATE_FI, STATE_ON, STATE_FO, STATE_OFF, STATE_IDLE } SeqState;

enum { enREP, enIN, enON, enOUT, enOFF, enNUM };

// ################################### Structures & Unions #########################################

typedef struct __attribute__((packed)) {
  union {
    uint16_t para[enNUM];
    uint16_t Rpt, tFI, tON, tFO, tOFF;
  };
  union {
    uint16_t frames[4];
    volatile uint16_t frFI, frON, frFO, frOFF;  // Sequence Configuration Registers (Parsed into 20ms Frame Counts)
  };
  volatile uint32_t incrFIfp, incrFOfp;         // Step Values (8.24 Fixed-Point)
  volatile uint16_t frameCounter, repeatsLeft;
} pwm_t;

// ##################################### Global variables ##########################################

// PWM for LED
pwm_t pwmInfo;
volatile SeqState currentState = STATE_IDLE;
volatile bool triggerIButtonRead = false;
volatile uint8_t baseTimerTicks = 0;
volatile uint32_t livePwmFP = 0;
volatile bool infiniteRepeats = false;
// bool for Relay
bool RLYstat = 0;

#if (USE_PWM_DRIVER == 0)
  #include "ow485-pwm-v0.h"
#elif (USE_PWM_DRIVER == 1)
  #include "ow485-pwm-v1.h"
#elif (USE_PWM_DRIVER == 2)
  #include "ow485-pwm-v2.h"
#else
  #error "Invalid version"
#endif

void SetLED(bool stat) { loadLedSequence(stat ? 65535 : 0, 0, stat ? 65535 : 0, 0, 0); }

void BlinkLED(int tms, int dly) { loadLedSequence(tms, 0, dly, 0, dly); }
