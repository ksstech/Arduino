// ow485-pwm-v2.h

ISR(TCB0_INT_vect) {
  const char * pState = NULL;
  TCB0.INTFLAGS = TCB_CAPT_bm;                        // clear the IRQ flag
  if (currentState == STATE_IDLE)
    goto exit;
  pwmInfo.frameCounter++;

  switch (currentState) {
    case STATE_FI:
      livePwmFP += pwmInfo.incrFIfp;
      if (pwmInfo.frameCounter >= pwmInfo.frFI) {
        pwmInfo.frameCounter = 0;
        livePwmFP = (uint32_t)255 << 24;
        TCA0.SPLIT.HCMP2 = 255;
        // Transitions
        if (pwmInfo.frON > 0)
          currentState = STATE_ON;
        else if (pwmInfo.frFO > 0)
          currentState = STATE_FO;
        else
          currentState = STATE_OFF; 
      } else {
        TCA0.SPLIT.HCMP2 = livePwmFP >> 24;
      }
      break;

    case STATE_ON:
      TCA0.SPLIT.HCMP2 = 255; // Force HIGH
      if (pwmInfo.frameCounter >= pwmInfo.frON) {
        pwmInfo.frameCounter = 0;
        // Transitions
        if (pwmInfo.frFO > 0)
          currentState = STATE_FO;
        else if (pwmInfo.frOFF > 0)
          currentState = STATE_OFF;
        else
          goto process_sequence_loop;
      }
      break;

    case STATE_FO:
      if (livePwmFP >= pwmInfo.incrFOfp)
        livePwmFP -= pwmInfo.incrFOfp;
      else
        livePwmFP = 0;
      if (pwmInfo.frameCounter >= pwmInfo.frFO) {
        pwmInfo.frameCounter = 0;
        TCA0.SPLIT.HCMP2 = 0;
        if (pwmInfo.frOFF > 0)
          currentState = STATE_OFF;
        else
          goto process_sequence_loop;
      } else {
        TCA0.SPLIT.HCMP2 = livePwmFP >> 24;
      }
      break;

    case STATE_OFF:
      TCA0.SPLIT.HCMP2 = 0; // Force LOW
      if (pwmInfo.frameCounter >= pwmInfo.frOFF)
        goto process_sequence_loop;
      break;
    default:
      break;
  }

  process_sequence_loop:
  pwmInfo.frameCounter = 0;
  if (infiniteRepeats || (pwmInfo.repeatsLeft > 1)) {
    if (infiniteRepeats == 0)
      --pwmInfo.repeatsLeft;
    // Prime the next cycle immediately
    if (pwmInfo.frFI > 0) {
        currentState = STATE_FI;
        livePwmFP = 0;
        TCA0.SPLIT.HCMP2 = 0;
        pState = "stateFI";
    } else if (pwmInfo.frON > 0) {
        currentState = STATE_ON;
        TCA0.SPLIT.HCMP2 = 255;
        pState = "stateON";
    } else if (pwmInfo.frFO > 0) {
        currentState = STATE_FO;
        livePwmFP = (uint32_t)255 << 24;
        TCA0.SPLIT.HCMP2 = 255;
        pState = "stateFO";
    } else if (pwmInfo.frOFF > 0) {
        currentState = STATE_OFF;
        pState = "stateOFF";
    }
  } else {
    currentState = STATE_IDLE;
    TCA0.SPLIT.HCMP2 = 0;
    pState = "stateIDLE";
  }
  if (pState)
    serialPrint(pState);
  exit:
  if (++baseTimerTicks == 10) {
    triggerIButtonRead = true;
    baseTimerTicks = 0;
  }
}

void startLedSequence(void) {
  uint8_t sreg = SREG;
  cli();
  if (pwmInfo.Rpt == 0) {
    currentState = STATE_IDLE;
    TCA0.SPLIT.HCMP2 = 0;
    SREG = sreg;
    return;
  }

  pwmInfo.frFI = (pwmInfo.tFI + 10) / 20;
  pwmInfo.frON = (pwmInfo.tON + 10) / 20;
  pwmInfo.frFO = (pwmInfo.tFO + 10) / 20;
  pwmInfo.frOFF = (pwmInfo.tOFF + 10) / 20;

  pwmInfo.incrFIfp = (pwmInfo.frFI > 0) ? (((uint32_t)255 << 24) / pwmInfo.frFI) : 0;
  pwmInfo.incrFOfp = (pwmInfo.frFO > 0) ? (((uint32_t)255 << 24) / pwmInfo.frFO) : 0;

  infiniteRepeats = (pwmInfo.Rpt == 65535);
  pwmInfo.repeatsLeft = pwmInfo.Rpt;
  pwmInfo.frameCounter = 0;
  
  // Set initial state and prime hardware
  if (pwmInfo.frFI > 0) {
    currentState = STATE_FI; 
    livePwmFP = 0; 
    TCA0.SPLIT.HCMP2 = 0;
  } else if (pwmInfo.frON > 0) {
    currentState = STATE_ON;
    TCA0.SPLIT.HCMP2 = 255;
  } else if (pwmInfo.frFO > 0) {
    currentState = STATE_FO;
    livePwmFP = (uint32_t)255 << 24;
    TCA0.SPLIT.HCMP2 = 255;
  } else if (pwmInfo.frOFF > 0) {
    currentState = STATE_OFF;
    TCA0.SPLIT.HCMP2 = 0;
  } else { 
    currentState = STATE_IDLE;
    TCA0.SPLIT.HCMP2 = 0;
  }
  
  SREG = sreg;
  #if (DEBUG_LEVEL > 0)
    char MsgBuf[128];
    snprintf(MsgBuf, sizeof(MsgBuf), "S=%d  frXX=%hu / %hu / %hu / %hu  IncrFx=%lX / %lx", currentState,
            pwmInfo.frFI, pwmInfo.frON, pwmInfo.frFO, pwmInfo.frOFF, pwmInfo.incrFIfp, pwmInfo.incrFOfp);
    serialPrint(MsgBuf);
  #endif
}

void loadLedSequence(uint16_t Rpt, uint16_t tFI, uint16_t tON, uint16_t tFO, uint16_t tOFF) {
  pwmInfo.Rpt = Rpt; pwmInfo.tFI = tFI; pwmInfo.tON = tON; pwmInfo.tFO = tFO; pwmInfo.tOFF = tOFF;
  startLedSequence();
}

void setup_pwm(void) {
  pinMode(pinLED, OUTPUT);
  analogWrite(pinLED, 1);               // Boots up TCA0 in Split Mode and attaches it to pin
  TCB0.CTRLA = 0;                       // Configure TCB0 for a solid 2ms baseline tick rate at 10MHz
  TCB0.CTRLB = TCB_CNTMODE_INT_gc;
  TCB0.CCMP = (F_CPU / 2) / 500;        // 10,000 hardware ticks = 2ms      
  TCB0.INTCTRL = TCB_CAPT_bm;          
  TCB0.CTRLA = TCB_CLKSEL_CLKDIV2_gc | TCB_ENABLE_bm;
  #if (DEBUG_LEVEL == 0)
    loadLedSequence(0, 0, 0, 0, 0);
  #else
    loadLedSequence(5, 2000, 1000, 2000, 1000);
  #endif
}
