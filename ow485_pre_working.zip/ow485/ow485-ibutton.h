// ow485-ibutton.h

//iButtonTag library return status codes
#define IBT_SUCCESS               1
#define IBT_NO_BUTTON             0
#define IBT_CHECKSUM              -1
#define IBT_ALL_ZEROS             -2
#define IBT_TYPE_INVALID          -11     // Write only
#define IBT_TYPE_NO_DETECT        -12     // Write only
#define IBT_TYPE_INCORRECT        -13     // Write only
#define IBT_TYPE_FAIL_CODE        -21     // Write only
#define IBT_TYPE_FAIL_RESP        -22     // Write only

// iButtonTag library button types
#define IBT_UNKNOWN               0

#define WAIT_TAG_PRESENT_MS       3000
#define WAIT_TAG_DELAY_MS         100

char * iButtonStatusMessage(void) {
    if (owStatus == IBT_SUCCESS)              return (char *) "Success ";
    else if (owStatus == IBT_NO_BUTTON)       return (char *) "No button ";
    else if (owStatus == IBT_CHECKSUM)        return (char *) "CRC Error ";
    else if (owStatus == IBT_ALL_ZEROS)       return (char *) "All 0's ";
    else if (owStatus == IBT_TYPE_INVALID)    return (char *) "Invalid ";
    else if (owStatus == IBT_TYPE_NO_DETECT)  return (char *) "WR No detect ";
    else if (owStatus == IBT_TYPE_INCORRECT)  return (char *) "WR Type wrong ";
    else if (owStatus == IBT_TYPE_FAIL_CODE)  return (char *) "WR Code fail ";
    else if (owStatus == IBT_TYPE_FAIL_RESP)  return (char *) "WR Response fail ";
    else                                      return (char *) "ERROR Undefined! ";
}

uint8_t iButtonRead(void) {
  owStatus = ibutton.readCode(owCode /*, true */ );   // Try read tag, compatibility with old DS1990 enabled
  if (DEBUG_LEVEL > 1) serialPrintOptions ("Read", PO_ONEWIRE);
  return owStatus;
}

void iButtonCheck(int msWait) {
  unsigned long msEnd = millis() + msWait;
  while(iButtonRead() == 0 && millis() < msEnd); 
}

void iButtonWrite(void) {
  // Try for a period to try for successful read of a tag...
  iButtonCheck(WAIT_TAG_PRESENT_MS);
  if (owStatus != 1)
    goto exit;
  // return if the remaining length is incorrect
  if (CmdBuf.length() < 12)
    goto exit;
  // convert 12 byte string into 6 byte / 48bit value in the buffer
  for (int i = 0, j = 1; i < 12; i += 2) {
    long int iVal = hostConsumeHexValue(2);
    if (iVal == -1)                         // value could not be read
      goto exit;
    owCode[j++] = (uint8_t) iVal;
  }
  // Update last byte of new ID-code to correct checksum
  ibutton.updateChecksum(owCode);
  /* Try to write the new ID-code
   * iButton tag type TM01 (including model TM01C) is non-detectable and _can_ be 
   * written. To write a new code to such a tag the specific type needs to be passed. */
  owStatus = ibutton.writeCode(owCode /*, IBUTTON_TM01*/);

  iButtonCheck(500);
  exit:
  if (DEBUG_LEVEL > 1) serialPrintOptions ("Write", PO_ONEWIRE);
}
