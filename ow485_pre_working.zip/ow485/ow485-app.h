/*
 * ow485-app.h
 *
 *  Date        Version   Comments
 *  2026/05/11  v0.1.0    Initial code
 *  2026/05/13  v0.1.1    Centralise all formatted print output in single function
 *  2026/05/16  v0.1.2    Add support for PWM on LED   
 *  2026/05/18  v0.1.3    Adds initial (non -functional) support for Serial1/UART1 debug output on PAx
 *  2026/05/18  v0.1.4    Separtated into multiple source headers
 *  2026/05/18  v0.1.5    Changes to PWM FSM
 *  2026/05/21  v0.1.6    Replace iButtonTag library with native OneWire functions
 */

#define _toSTR(x)				          #x
#define toSTR(x)				          _toSTR(x)

#define DEV_FW_NAME               "Irmacos"
#define DEV_FW_MAJ                0
#define DEV_FW_MIN                1
#define DEV_FW_FIX                6
#define DEV_FW_INFO               DEV_FW_NAME " v" toSTR(DEV_FW_MAJ) "." toSTR(DEV_FW_MIN) "." toSTR(DEV_FW_FIX)

// USERROW usage
#define UR_IDX_DEVID              0         // first byte in the array

// format content control options
#define PO_CHANNEL                0x0001
#define PO_ADDR                   0x0002
#define PO_UPTIME                 0x0004

#define PO_ONEWIRE                0x0010

#define PO_RLY_LED                0x0100

#define PO_EEPROM                 0x0200
#define PO_USERROW                0x0400

#define PO_FIRMWARE               0x1000
#define PO_CMDBUF                 0x2000
#define PO_SYSSTAT                0x4000

// ##################################### Global variables ##########################################

// 1W & iButton variables
int8_t owStatus;
uint8_t owAddr;
#if (USE_IBUTTON_TAG == 1)
  iButtonTag ibutton(pinOneWire);          // Setup iButtonTag on the selected pin
#else
  OneWire oneWire(pinOneWire);
  typedef uint8_t iButtonCode[8];
  uint8_t owPresent;
#endif
iButtonCode owCode = { 0 };
// Counters
uint32_t countRD0 = 0, countRD1 = 0, countRD2 = 0;

String CmdBuf = "";                   // buffer containing data from master/mote

// Forward declared functions
void serialPrint(const char * pString);
void serialPrintOptions(const char * pString, int Options);
char hostConsumeChar(void);
char hostConsumeHexChar(void);
long int hostConsumeHexValue(int8_t);
uint8_t hostConsumeString(char *, uint8_t);
bool hostReadCmd(void);

char * iButtonStatusMessage(void);

void SetLED(bool stat);
