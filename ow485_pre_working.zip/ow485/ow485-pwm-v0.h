// ow485-pwm-v0.h

// 2ms Base Timer Interrupt
ISR(TCB0_INT_vect) {
  TCB0.INTFLAGS = TCB_CAPT_bm; 
  baseTimerTicks++;
  if (baseTimerTicks < 10)
    return;                         // Ticks 1 to 9 drop out instantly to prioritize OneWire bit-banging
  baseTimerTicks = 0;               // 20ms Cinematic frame boundary reached!
  if (currentState == STATE_IDLE)
    return;
  ++pwmInfo.frameCounter;
  switch (currentState) {
    case STATE_FI:
      livePwmFP += pwmInfo.incrFIfp;
      if (pwmInfo.frameCounter >= pwmInfo.frFI) {
        pwmInfo.frameCounter = 0;
        livePwmFP = (uint32_t)255 << 24;
        TCA0.SPLIT.HCMP2 = 255;
        if (pwmInfo.frON > 0)         currentState = STATE_ON;
        else if (pwmInfo.frFO > 0)    currentState = STATE_FO;
        else if (pwmInfo.frOFF > 0)   currentState = STATE_OFF;
        else                          goto process_sequence_loop;
      } else {
        TCA0.SPLIT.HCMP2 = livePwmFP >> 24;
      }
      break;

    case STATE_ON:
      TCA0.SPLIT.HCMP2 = 255;
      if (pwmInfo.frameCounter >= pwmInfo.frON) {
        pwmInfo.frameCounter = 0;
        if (pwmInfo.frFO > 0)         currentState = STATE_FO;
        else if (pwmInfo.frOFF > 0)   currentState = STATE_OFF;
        else                          goto process_sequence_loop;
      }
      break;

    case STATE_FO:
      if (livePwmFP >= pwmInfo.incrFOfp)   livePwmFP -= pwmInfo.incrFOfp;
      else                              livePwmFP = 0;
      if (pwmInfo.frameCounter >= pwmInfo.frFO) {
        pwmInfo.frameCounter = 0;
        livePwmFP = 0;
        TCA0.SPLIT.HCMP2 = 0;                
        if (pwmInfo.frOFF > 0)        currentState = STATE_OFF;
        else                          goto process_sequence_loop;
      } else {
        TCA0.SPLIT.HCMP2 = livePwmFP >> 24;
      }
      break;

    case STATE_OFF:
      TCA0.SPLIT.HCMP2 = 0;
      if (pwmInfo.frameCounter >= pwmInfo.frOFF) {
          goto process_sequence_loop;
      }
      break;
    default:
      break;
  }
  triggerIButtonRead = true; 
  return;

process_sequence_loop:
  pwmInfo.frameCounter = 0;
  if (infiniteRepeats || pwmInfo.repeatsLeft) {
    if (infiniteRepeats == 0)
      --pwmInfo.repeatsLeft;
    if (pwmInfo.frFI > 0) {
      currentState = STATE_FI;
    } else if (pwmInfo.frON > 0) {
      currentState = STATE_ON;
      livePwmFP = (uint32_t)255 << 24;
      TCA0.SPLIT.HCMP2 = 255;
    } else if (pwmInfo.frFO > 0) {
      currentState = STATE_FO;
      livePwmFP = (uint32_t)255 << 24;
      TCA0.SPLIT.HCMP2 = 255;
    } else if (pwmInfo.frOFF > 0) {
      currentState = STATE_OFF;
    }
  } else {
    TCA0.SPLIT.HCMP2 = 0;
    currentState = STATE_IDLE;
  }
  triggerIButtonRead = true;
}

void startLedSequence(void) {
  uint8_t sreg = SREG;
  cli(); // Atomic block protection for multi-byte values
  if (pwmInfo.Rpt == 0) {
    currentState = STATE_IDLE;
    TCA0.SPLIT.HCMP2 = 0; // Turn off LED
    SREG = sreg;
    return;
  }

  // Convert millisecond inputs into discrete 20ms cinematic frames
  pwmInfo.frFI  = (pwmInfo.tFI + 10) / 20;
  pwmInfo.frON  = (pwmInfo.tON + 10) / 20;
  pwmInfo.frFO  = (pwmInfo.tFO + 10) / 20;
  pwmInfo.frOFF = (pwmInfo.tOFF + 10) / 20;

  // Calculate fixed-point 8.24 delta modifications per frame
  pwmInfo.incrFIfp = (pwmInfo.frFI > 0) ? (((uint32_t)255 << 24) / pwmInfo.frFI) : 0;
  pwmInfo.incrFOfp = (pwmInfo.frFO > 0) ? (((uint32_t)255 << 24) / pwmInfo.frFO) : 0;

  // FIXED: 65535 sets the infinite looping flag
  infiniteRepeats = (pwmInfo.Rpt == 65535);
  pwmInfo.repeatsLeft = pwmInfo.Rpt;
  livePwmFP = 0;
  pwmInfo.frameCounter = 0;
  baseTimerTicks = 0;
  TCA0.SPLIT.HCMP2 = 0; // Ensure LED starts fully off

  // Evaluate the starting state based on which parameters contain valid runtimes
  if (pwmInfo.frFI > 0) {
    currentState = STATE_FI;
  } else if (pwmInfo.frON > 0) {
    currentState = STATE_ON;
    livePwmFP = (uint32_t)255 << 24;
    TCA0.SPLIT.HCMP2 = 255;
  } else if (pwmInfo.frFO > 0) {
    currentState = STATE_FO;
    livePwmFP = (uint32_t)255 << 24;
    TCA0.SPLIT.HCMP2 = 255;
  } else if (pwmInfo.frOFF > 0) {
    currentState = STATE_OFF;
  } else {
    currentState = STATE_IDLE;
  }
  SREG = sreg;
}

/**
 * 
 * note repeats = 0      -> Stops the sequence instantly.
 *      repeats = 65535  -> Continues indefinitely
 */
void loadLedSequence(uint16_t Rpt, uint16_t tFI, uint16_t tON, uint16_t tFO, uint16_t tOFF) {
  pwmInfo.Rpt = Rpt;
  pwmInfo.tFI = tFI;
  pwmInfo.tON = tON;
  pwmInfo.tFO = tFO;
  pwmInfo.tOFF = tOFF;
  startLedSequence();
}

void setup_pwm(void) {
  pinMode(pinLED, OUTPUT);
  analogWrite(pinLED, 1);               // Boots up TCA0 in Split Mode and attaches it to PA5
  TCB0.CTRLA = 0;                       // Configure TCB0 for a solid 2ms baseline tick rate at 10MHz
  TCB0.CTRLB = TCB_CNTMODE_INT_gc;
  TCB0.CCMP = (F_CPU / 2) / 500;        // 10,000 hardware ticks = 2ms      
  TCB0.INTCTRL = TCB_CAPT_bm;          
  TCB0.CTRLA = TCB_CLKSEL_CLKDIV2_gc | TCB_ENABLE_bm;
  #if (DEBUG_LEVEL == 0)
    loadLedSequence(0, 0, 0, 0, 0);
  #else
    loadLedSequence(5, 2000, 1000, 2000, 1000);
  #endif
}
