// ow485-onewire.h

//iButtonTag library return status codes
#define IBT_SUCCESS               1
#define IBT_NO_BUTTON             0
#define IBT_CHECKSUM              -1
#define IBT_ALL_ZEROS             -2
#define IBT_TYPE_INVALID          -11     // Write only
#define IBT_TYPE_NO_DETECT        -12     // Write only
#define IBT_TYPE_INCORRECT        -13     // Write only
#define IBT_TYPE_FAIL_CODE        -21     // Write only
#define IBT_TYPE_FAIL_RESP        -22     // Write only

#define WAIT_TAG_PRESENT_MS       3000
#define WAIT_TAG_DELAY_MS         100

char * iButtonStatusMessage(void) {
    if (owStatus == IBT_SUCCESS)              return (char *) "Success ";
    else if (owStatus == IBT_NO_BUTTON)       return (char *) "No button ";
    else if (owStatus == IBT_CHECKSUM)        return (char *) "CRC Error ";
    else if (owStatus == IBT_ALL_ZEROS)       return (char *) "All 0's ";
    else if (owStatus == IBT_TYPE_INVALID)    return (char *) "Invalid ";
    else if (owStatus == IBT_TYPE_NO_DETECT)  return (char *) "WR No detect ";
    else if (owStatus == IBT_TYPE_INCORRECT)  return (char *) "WR Type wrong ";
    else if (owStatus == IBT_TYPE_FAIL_CODE)  return (char *) "WR Code fail ";
    else if (owStatus == IBT_TYPE_FAIL_RESP)  return (char *) "WR Response fail ";
    else                                      return (char *) "ERROR Undefined! ";
}

void iButtonReset(void) { owPresent = oneWire.reset(); }

uint8_t iButtonCRCverify(void) { return (owStatus = OneWire::crc8(owCode, 7)) == owCode[7] ? IBT_SUCCESS : IBT_CHECKSUM; }

void iButtonCRCupdate(void) { owCode[7] = OneWire::crc8(owCode, 7); }

uint8_t iButtonRead(void) {
  iButtonReset();
  if (oneWire.search(owCode)) {
    iButtonCRCverify();
  } else {
    owStatus = IBT_NO_BUTTON;
  }
  if (DEBUG_LEVEL > 1) serialPrintOptions ("Read", PO_ONEWIRE);
  return owStatus;
}

void iButtonReadWait(uint32_t msWait) {
  msWait += millis();
  while((iButtonRead() == 0) && (millis() < msWait));
}

void iButtonWrite(void) {
  iButtonCode owCodeCheck = { 0 };
  // Try for a period to try for successful read of a tag...
  iButtonReadWait(WAIT_TAG_PRESENT_MS);
  if (owStatus != 1)
    goto exit;
  // return if the remaining length is incorrect
  if (CmdBuf.length() < 12)
    goto exit;
  // convert 12 byte string into 6 byte / 48bit value in the buffer
  for (int i = 0, j = 1; i < 12; i += 2) {
    long int iVal = hostConsumeHexValue(2);
    if (iVal == -1)                         // value could not be read
      goto exit;
    owCode[j++] = (uint8_t) iVal;
  }
  // Update last byte of new ID-code to correct checksum
  iButtonCRCupdate();
  /* Try to write the new ID-code
   * iButton tag type TM01 (including model TM01C) is non-detectable and _can_ be 
   * written. To write a new code to such a tag the specific type needs to be passed. */
  
  // Step 1: Issue Write-Unprotect sequence to prepare the RW1990 memory matrix
  oneWire.reset();
  oneWire.write(0xD1);      // RW1990 unprotect command sequence
  oneWire.write_bit(0);     // Lower write-protect state line bit
  delay(10);                // Minimum burn duration requirement

  // Step 2: Clear old memory registers
  oneWire.reset();
  oneWire.write(0xD5);      // Command entry to register write phase
  for (uint8_t i = 0; i < 8; ++i) {
    // Write inverted byte sequences required by the hardware ASIC programming layout
    uint8_t invertedByte = ~owCode[i];
    for (uint8_t bit = 0; bit < 8; ++bit) {
      oneWire.write_bit(invertedByte & 0x01);
      invertedByte >>= 1;
    }
  }
  delay(30); // Allow hardware internal configuration registers to bake

  // Step 3: Re-verify what was written
  oneWire.reset_search();
  
  owStatus = IBT_SUCCESS;
  if (oneWire.search(owCodeCheck)) {      // will only work if the tag just written is the 
    owStatus = IBT_TYPE_FAIL_CODE;        // ONLY tag on the bus.
    for (uint8_t i = 0; i < 8; i++) {
      if (owCodeCheck[i] != owCode[i]) {
        owStatus = IBT_TYPE_FAIL_CODE;
        break;
      }
    }
  } else {
    owStatus = IBT_NO_BUTTON;
  }
  // all done...
  exit:
  if (DEBUG_LEVEL > 1) serialPrintOptions ("Write", PO_ONEWIRE);
}
